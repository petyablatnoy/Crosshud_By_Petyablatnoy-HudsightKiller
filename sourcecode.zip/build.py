import os
import shutil
import subprocess
import sys

def install_deps():
    pkgs = ['pyinstaller', 'PySide6', 'Pillow']
    for p in pkgs:
        try:
            __import__(p.lower())
        except ImportError:
            subprocess.run([sys.executable, '-m', 'pip', 'install', p], check=True)
    return True

def build():
    cmd = [
        'pyinstaller',
        '--name=CrossHud_By_PetyaBlatnoy',
        '--onedir',
        '--windowed',
        '--noconfirm',
        '--clean',
        '--collect-binaries=PySide6',
        '--uac-uiaccess',
        '--icon=icon.ico',
        '--add-data=icon.ico;.',
        '--hidden-import=PySide6',
        '--hidden-import=PIL',
        '--hidden-import=PIL.Image',
        '--hidden-import=PIL.ImageDraw',
        'main_file.py'
    ]
    try:
        subprocess.run(cmd, check=True)
        dist_dir = os.path.join('dist', 'CrossHud_By_PetyaBlatnoy')
        if os.path.exists('icon.ico') and os.path.exists(dist_dir):
            shutil.copy('icon.ico', os.path.join(dist_dir, 'icon.ico'))
        return True
    except subprocess.CalledProcessError:
        return False

def sign():
    s = "sign_app.ps1"
    if not os.path.exists(s):
        return False
    try:
        subprocess.run(["powershell", "-ExecutionPolicy", "Bypass", "-File", s], check=True)
        return True
    except subprocess.CalledProcessError:
        return False 

def pack():
    p86 = os.environ.get("ProgramFiles(x86)", "")
    p = os.environ.get("ProgramFiles", "")
    m = None
    for path in [os.path.join(p86, "NSIS", "makensis.exe"), os.path.join(p, "NSIS", "makensis.exe")]:
        if os.path.exists(path):
            m = path
            break
    if not m:
        return False
    try:
        subprocess.run(f'chcp 65001 > nul && "{m}" /INPUTCHARSET UTF8 installer.nsi', shell=True, check=True)
        return True
    except subprocess.CalledProcessError:
        return False

def main():
    try:
        if os.path.isdir('dist'): shutil.rmtree('dist')
        if os.path.isdir('build'): shutil.rmtree('build')
    except: pass
    if not install_deps(): sys.exit(1)
    if not build(): sys.exit(1)
    if not sign(): sys.exit(1)
    if not pack(): sys.exit(1)

if __name__ == "__main__":
    main()