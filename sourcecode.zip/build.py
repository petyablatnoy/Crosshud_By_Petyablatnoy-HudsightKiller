import os
import shutil
import subprocess
import sys

try:
    from PIL import Image, ImageDraw
except ImportError:
    print("PIL/Pillow не найден. Попытка установить...")
    subprocess.run([sys.executable, '-m', 'pip', 'install', 'Pillow'], check=True)
    from PIL import Image, ImageDraw

def install_dependencies():
    """Устанавливает PyInstaller, если он не установлен."""
    print("[1/3] Проверка и установка зависимостей...")
    try:
        import PyInstaller
        print(" - PyInstaller уже установлен.")
    except ImportError:
        print(" - PyInstaller не найден, установка...")
        try:
            subprocess.run([sys.executable, '-m', 'pip', 'install', 'pyinstaller'], check=True)
            print(" - PyInstaller успешно установлен.")
        except Exception as e:
            print(f"ОШИБКА: Не удалось установить PyInstaller: {e}")
            return False
    print(" - Зависимости в порядке.")
    return True

def create_icon():
    """Создает иконку для .exe файла."""
    try:
        img = Image.new('RGBA', (256, 256), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.line([(128, 40), (128, 216)], fill=(0, 255, 0, 255), width=16)
        draw.line([(40, 128), (216, 128)], fill=(0, 255, 0, 255), width=16)
        draw.ellipse([112, 112, 144, 144], fill=(255, 0, 0, 255))
        img.save('icon.ico', sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (256, 256)])
        print(" - Файл иконки 'icon.ico' успешно создан.")
        return True
    except Exception as e:
        print(f"ОШИБКА: Ошибка при создании иконки: {e}")
        return False

def build_executable():
    """Собирает исполняемый файл с помощью PyInstaller."""
    print("\n[2/3] Сборка исполняемого файла (.exe)...")
    if not create_icon():
        print("Сборка прервана из-за ошибки создания иконки.")
        return False

    os.environ['PYTHONIOENCODING'] = 'utf-8'
    pyinstaller_command = [
        'pyinstaller',
        '--name=CrossHud_By_PetyaBlatnoy',
        '--onefile',
        '--windowed',
        '--icon=icon.ico',
        '--hidden-import=pystray._win32',
        '--clean',
        'main_file.py'
    ]
    try:
        result = subprocess.run(pyinstaller_command, check=True, shell=True, capture_output=True, text=True, encoding='utf-8')
        print(" - Исполняемый файл успешно собран в папке 'dist'.")
        return True
    except subprocess.CalledProcessError as e:
        print(f"ОШИБКА: Сборка .exe провалилась.")
        print(f"STDOUT: {e.stdout}")
        print(f"STDERR: {e.stderr}")
        return False
    finally:
        if os.path.exists('icon.ico'): os.remove('icon.ico')
        if os.path.exists('CrossHud_By_PetyaBlatnoy.spec'): os.remove('CrossHud_By_PetyaBlatnoy.spec')
        if os.path.isdir('build'): shutil.rmtree('build')
        print(" - Временные файлы сборки очищены.")

def find_nsis():
    """Находит путь к компилятору NSIS (makensis.exe)."""
    program_files = os.environ.get("ProgramFiles", r"C:\Program Files")
    program_files_x86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
    
    possible_paths = [
        os.path.join(program_files_x86, "NSIS", "makensis.exe"),
        os.path.join(program_files, "NSIS", "makensis.exe"),
    ]
    for path in possible_paths:
        if os.path.exists(path):
            print(f" - NSIS найден: {path}")
            return path
    return None

def compile_installer():
    """Компилирует NSIS скрипт для создания установщика."""
    print("\n[3/3] Создание установщика (setup.exe)...")
    makensis_path = find_nsis()
    if not makensis_path:
        print("ОШИБКА: NSIS не найден.")
        print("Пожалуйста, установите NSIS с сайта https://nsis.sourceforge.io/")
        return False
    
    if not os.path.exists("icon.ico"):
        create_icon()

    try:
        command = f'chcp 65001 > nul && "{makensis_path}" /INPUTCHARSET UTF8 installer.nsi'
        result = subprocess.run(
            command,
            shell=True,
            check=True,
            capture_output=True,
            text=True,
            encoding='utf-8'
        )
        print(" - Установщик успешно создан в папке 'dist'.")
        return True
    except subprocess.CalledProcessError as e:
        print("ОШИБКА: Сборка установщика провалилась.")
        print(f"STDOUT: {e.stdout}")
        print(f"STDERR: {e.stderr}")
        return False
    finally:
        if os.path.exists('icon.ico'):
            os.remove('icon.ico')


def main():
    """Основная функция сборки."""
    if not install_dependencies():
        sys.exit(1)
        
    if not build_executable():
        sys.exit(1)

    if not compile_installer():
        sys.exit(1)
        
    print("\n========================================================")
    print(" ГОТОВО!")
    print(" Установщик создан: dist\CrossHud_By_PetyaBlatnoy_Setup.exe")
    print("========================================================")

if __name__ == "__main__":
    main()
