#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Вкладка логирования для CrossHud_By_PetyaBlatnoy.
Отображает логи приложения в реальном времени.
"""
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import logging
import threading
import queue
import os
from datetime import datetime
class LoggerTab:
    """Управляет вкладкой логирования в интерфейсе."""
    def __init__(self, parent_frame):
        """
        Инициализация вкладки логирования.
        
        Args:
            parent_frame: Родительский фрейм для размещения элементов
        """
        self.parent_frame = parent_frame
        self.log_queue = queue.Queue()
        self.log_handler = None
        self.auto_scroll = tk.BooleanVar(value=True)
        self.log_level = tk.StringVar(value="INFO")
        self.create_logger_ui()
        self.setup_log_handler()
        self.start_log_monitoring()
    def create_logger_ui(self) -> None:
        """Создание интерфейса вкладки логирования."""
        title_label = tk.Label(self.parent_frame, text="Журнал событий", 
                              font=("Arial", 14, "bold"))
        title_label.pack(pady=10)
        control_frame = ttk.Frame(self.parent_frame)
        control_frame.pack(fill="x", padx=10, pady=5)
        ttk.Label(control_frame, text="Уровень:").pack(side="left")
        level_combo = ttk.Combobox(control_frame, textvariable=self.log_level,
                                  values=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
                                  state="readonly", width=10)
        level_combo.pack(side="left", padx=5)
        level_combo.bind("<<ComboboxSelected>>", self.on_log_level_change)
        auto_scroll_cb = ttk.Checkbutton(control_frame, text="Автопрокрутка",
                                        variable=self.auto_scroll)
        auto_scroll_cb.pack(side="left", padx=10)
        btn_frame = ttk.Frame(control_frame)
        btn_frame.pack(side="right")
        ttk.Button(btn_frame, text="Очистить", 
                  command=self.clear_logs).pack(side="left", padx=2)
        ttk.Button(btn_frame, text="Сохранить", 
                  command=self.save_logs).pack(side="left", padx=2)
        ttk.Button(btn_frame, text="Открыть папку", 
                  command=self.open_log_folder).pack(side="left", padx=2)
        log_frame = ttk.Frame(self.parent_frame)
        log_frame.pack(fill="both", expand=True, padx=10, pady=5)
        self.log_text = scrolledtext.ScrolledText(
            log_frame,
            wrap=tk.WORD,
            height=20,
            font=("Consolas", 9),
            bg="#f0f0f0"
        )
        self.log_text.pack(fill="both", expand=True)
        self.setup_log_tags()
        stats_frame = ttk.Frame(self.parent_frame)
        stats_frame.pack(fill="x", padx=10, pady=5)
        self.stats_label = ttk.Label(stats_frame, text="Готов к работе")
        self.stats_label.pack(side="left")
        self.message_count = {"DEBUG": 0, "INFO": 0, "WARNING": 0, "ERROR": 0, "CRITICAL": 0}
        self.update_stats()
    def setup_log_tags(self) -> None:
        """Настройка тегов для цветного отображения логов."""
        self.log_text.tag_config("DEBUG", foreground="#808080")
        self.log_text.tag_config("INFO", foreground="#000000")
        self.log_text.tag_config("WARNING", foreground="#FFA500")
        self.log_text.tag_config("ERROR", foreground="#FF0000")
        self.log_text.tag_config("CRITICAL", foreground="#8B0000", background="#FFE4E1")
        self.log_text.tag_config("TIMESTAMP", foreground="#0000FF")
    def setup_log_handler(self) -> None:
        """Настройка обработчика логов для перехвата сообщений."""
        class QueueHandler(logging.Handler):
            def __init__(self, log_queue):
                super().__init__()
                self.log_queue = log_queue
            def emit(self, record):
                self.log_queue.put(record)
        self.log_handler = QueueHandler(self.log_queue)
        self.log_handler.setLevel(getattr(logging, self.log_level.get()))
        root_logger = logging.getLogger()
        root_logger.addHandler(self.log_handler)
    def start_log_monitoring(self) -> None:
        """Запуск мониторинга логов в отдельном потоке."""
        def monitor_logs():
            while True:
                try:
                    record = self.log_queue.get(timeout=0.1)
                    self.parent_frame.after(0, self.display_log_record, record)
                except queue.Empty:
                    continue
        log_thread = threading.Thread(target=monitor_logs, daemon=True)
        log_thread.start()
    def display_log_record(self, record) -> None:
        """Отображение записи лога в текстовом виджете."""
        try:
            timestamp = datetime.fromtimestamp(record.created).strftime("%H:%M:%S")
            level = record.levelname
            message = record.getMessage()
            log_line = f"[{timestamp}] {level}: {message}\n"
            self.log_text.insert(tk.END, f"[{timestamp}] ", "TIMESTAMP")
            self.log_text.insert(tk.END, f"{level}: ", level)
            self.log_text.insert(tk.END, f"{message}\n")
            if level in self.message_count:
                self.message_count[level] += 1
                self.update_stats()
            if self.auto_scroll.get():
                self.log_text.see(tk.END)
            lines = self.log_text.get("1.0", tk.END).count('\n')
            if lines > 1000:
                self.log_text.delete("1.0", "100.0")
        except Exception as e:
            print(f"Ошибка отображения лога: {e}")
    def on_log_level_change(self, event=None) -> None:
        """Обработка изменения уровня логирования."""
        new_level = self.log_level.get()
        if self.log_handler:
            self.log_handler.setLevel(getattr(logging, new_level))
        logging.info(f"Уровень логирования изменен на {new_level}")
    def clear_logs(self) -> None:
        """Очистка отображаемых логов."""
        self.log_text.delete("1.0", tk.END)
        self.message_count = {"DEBUG": 0, "INFO": 0, "WARNING": 0, "ERROR": 0, "CRITICAL": 0}
        self.update_stats()
        logging.info("Журнал событий очищен")
    def save_logs(self) -> None:
        """Сохранение логов в файл."""
        try:
            filename = filedialog.asksaveasfilename(
                title="Сохранить журнал",
                defaultextension=".log",
                filetypes=[("Файлы логов", "*.log"), ("Текстовые файлы", "*.txt"), ("Все файлы", "*.*")]
            )
            if filename:
                content = self.log_text.get("1.0", tk.END)
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(f"Журнал CrossHud_By_PetyaBlatnoy\n")
                    f.write(f"Сохранено: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                    f.write("=" * 50 + "\n\n")
                    f.write(content)
                messagebox.showinfo("Сохранение", f"Журнал сохранен в:\n{filename}")
                logging.info(f"Журнал сохранен в файл: {filename}")
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось сохранить журнал:\n{e}")
            logging.error(f"Ошибка сохранения журнала: {e}")
    def open_log_folder(self) -> None:
        """Открытие папки с файлами логов."""
        try:
            log_dir = os.path.join(os.path.expanduser("~"), "CrossHud_By_PetyaBlatnoy", "logs")
            if os.path.exists(log_dir):
                os.startfile(log_dir)
                logging.info(f"Открыта папка с логами: {log_dir}")
            else:
                messagebox.showwarning("Предупреждение", "Папка с логами не найдена")
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось открыть папку с логами:\n{e}")
            logging.error(f"Ошибка открытия папки с логами: {e}")
    def update_stats(self) -> None:
        """Обновление статистики сообщений."""
        total = sum(self.message_count.values())
        errors = self.message_count["ERROR"] + self.message_count["CRITICAL"]
        warnings = self.message_count["WARNING"]
        stats_text = f"Всего сообщений: {total} | Ошибки: {errors} | Предупреждения: {warnings}"
        self.stats_label.configure(text=stats_text)
    def add_test_messages(self) -> None:
        """Добавление тестовых сообщений (для отладки)."""
        logging.debug("Отладочное сообщение")
        logging.info("Информационное сообщение")
        logging.warning("Предупреждение")
        logging.error("Сообщение об ошибке")
        logging.critical("Критическая ошибка")