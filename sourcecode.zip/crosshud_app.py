import sys
import os
import logging
import atexit
from PySide6.QtWidgets import QApplication, QSystemTrayIcon, QMenu
from PySide6.QtGui import QIcon, QAction, QPixmap
from PySide6.QtCore import Signal, QObject, Qt, QTimer
from settings_manager import SettingsManager
from overlay_manager import OverlayManager
from ui_components import UIComponents
from resolution_detector import ResolutionDetector

class Signaler(QObject):
    toggle_trigger = Signal()

class CrossHudApp:
    def __init__(self):
        self.app = QApplication(sys.argv)
        self.app.setQuitOnLastWindowClosed(False)
        self.main_icon = self.get_best_icon()
        self.app.setWindowIcon(self.main_icon)
        self.settings = SettingsManager()
        self.res_detector_active = True
        self.signaler = Signaler()
        self.signaler.toggle_trigger.connect(self.toggle_crosshair_logic)
        self.overlay = OverlayManager(self.settings, self.signaler.toggle_trigger.emit)
        self.window = UIComponents(self.settings, self.overlay, self.main_icon)
        self.tray = None
        self.res = ResolutionDetector.get_resolution()
        self.settings.set_resolution(*self.res)
        ResolutionDetector.monitor_resolution_changes(self.on_res_change)
        
    def get_best_icon(self):
        icon_path = "icon.ico"
        if getattr(sys, 'frozen', False):
            base_dir = os.path.dirname(sys.executable)
            icon_path = os.path.join(base_dir, "icon.ico")
        if os.path.exists(icon_path):
            icon = QIcon(icon_path)
            if not icon.isNull():
                return icon
        pixmap = QPixmap(16, 16)
        pixmap.fill(Qt.green)
        return QIcon(pixmap)

    def setup_tray(self):
        if self.tray: return
        self.tray = QSystemTrayIcon(self.app)
        self.tray.setIcon(self.main_icon)
        self.tray.setToolTip("CrossHud")
        menu = QMenu()
        show_action = QAction("Меню", menu)
        show_action.triggered.connect(self.toggle_window)
        exit_action = QAction("Выход", menu)
        exit_action.triggered.connect(self.exit_app)
        menu.addAction(show_action)
        menu.addAction(exit_action)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self.on_tray_click)
        self.tray.show()

    def on_tray_click(self, reason):
        if reason == QSystemTrayIcon.Trigger:
            self.toggle_window()

    def toggle_window(self):
        if self.window.isVisible():
            self.window.hide()
        else:
            self.window.show()
            self.window.activateWindow()
            self.window.raise_()

    def toggle_crosshair_logic(self):
        new_state = not self.settings.get('enabled', False)
        self.settings.set('enabled', new_state)
        if new_state:
            self.overlay.show()
        else:
            self.overlay.hide()
        self.window.update_enable_switch(new_state)

    def on_res_change(self, o, n):
        self.settings.set_resolution(*n)
        self.overlay.request_recreation()

    def exit_app(self):
        try:
            self.settings.save_settings()
            self.overlay.cleanup()
        except: pass
        self.app.quit()

    def run(self, start_minimized=False):
        def startup_logic():
            self.setup_tray()
            if not start_minimized:
                self.window.show()
                self.window.raise_()
            QTimer.singleShot(50, lambda: self.overlay.show() if self.settings.get('enabled', True) else None)
        QTimer.singleShot(100, startup_logic)
        sys.exit(self.app.exec())