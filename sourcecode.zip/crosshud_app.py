#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CrossHud_By_PetyaBlatnoy v2.1

Главный класс приложения для продвинутого прицела-оверлея.
Координирует все компоненты и управляет жизненным циклом приложения.
"""
import tkinter as tk
import logging
import os
import sys
import atexit
import signal
from datetime import datetime
from settings_manager import SettingsManager
from overlay_manager import OverlayManager
from pixel_editor import PixelEditor
from ui_components import UIComponents
from logger_tab import LoggerTab
from resolution_detector import ResolutionDetector
try:
    import pystray
    from PIL import Image, ImageDraw
    TRAY_AVAILABLE = True
except ImportError:
    TRAY_AVAILABLE = False
    print("Warning: pystray not available, tray functionality will be disabled")
try:
    import win32gui
    import win32con
    WIN32_AVAILABLE = True
except ImportError:
    WIN32_AVAILABLE = False
class CrossHudApp:
    """Главный класс приложения, который координирует все компоненты."""
    def __init__(self):
        """Инициализация приложения прицела-оверлея."""
        # self.setup_logging() # Удалено, т.к. логирование настраивается в main_file.py
        self.is_closing = False
        self.force_exit = False
        self.root = tk.Tk()
        self.tray_icon = None
        self.settings_manager = SettingsManager()
        self.init_resolution()
        ResolutionDetector.monitor_resolution_changes(self.on_resolution_changed)
        self.overlay_manager = OverlayManager(
            self.root,
            self.settings_manager,
            on_toggle_callback=self.toggle_overlay_from_manager
        )
        self.pixel_editor = PixelEditor(
            self.root,
            self.settings_manager,
            on_apply_callback=self.on_pixel_design_applied
        )
        self.ui_components = UIComponents(
            self.root,
            self.settings_manager,
            self.overlay_manager,
            self.pixel_editor
        )
        self.setup_lifecycle_handlers()
        self.setup_tray()
        logging.info("CrossHud_By_PetyaBlatnoy инициализирован")

    # def setup_logging(self) -> None: ... # Метод удален

    def setup_lifecycle_handlers(self) -> None:
        """Настройка обработчиков событий жизненного цикла приложения."""
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.root.bind("<Map>", self.on_window_mapped)
        self.root.bind("<Unmap>", self.on_window_unmapped)
        atexit.register(self.cleanup)
        if hasattr(signal, 'SIGTERM'):
            signal.signal(signal.SIGTERM, self.signal_handler)
        if hasattr(signal, 'SIGINT'):
            signal.signal(signal.SIGINT, self.signal_handler)
    def signal_handler(self, signum, frame):
        """Обработчик системных сигналов."""
        logging.info(f"Получен сигнал {signum}, завершение приложения...")
        self.force_exit = True
        self.cleanup()
        sys.exit(0)
    def create_tray_icon(self):
        """Создание иконки для системного трея."""
        image = Image.new('RGB', (64, 64), color='black')
        draw = ImageDraw.Draw(image)
        draw.line([(32, 16), (32, 48)], fill='green', width=4)
        draw.line([(16, 32), (48, 32)], fill='green', width=4)
        draw.ellipse([28, 28, 36, 36], fill='red')
        return image
    def setup_tray(self) -> None:
        """Настройка системного трея."""
        if not TRAY_AVAILABLE:
            logging.warning("Pystray не доступен, функция трея отключена")
            return
        try:
            menu = pystray.Menu(
                pystray.MenuItem("Показать/Скрыть", self.toggle_main_window, default=True),
                pystray.MenuItem("Включить/Выключить прицел", self.toggle_overlay),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("Выход", self.exit_application)
            )
            icon_image = self.create_tray_icon()
            self.tray_icon = pystray.Icon("CrossHud", icon_image, "CrossHud_By_PetyaBlatnoy", menu)
            import threading
            self.tray_thread = threading.Thread(target=self.run_tray, daemon=True)
            self.tray_thread.start()
            logging.info("Системный трей инициализирован")
        except Exception as e:
            logging.error(f"Ошибка инициализации трея: {e}")
            self.tray_icon = None
    def run_tray(self) -> None:
        """Запуск системного трея."""
        try:
            if self.tray_icon:
                self.tray_icon.run()
        except Exception as e:
            logging.error(f"Ошибка работы трея: {e}")
    def toggle_main_window(self, icon=None, item=None) -> None:
        """Переключение видимости главного окна."""
        try:
            if self.root.winfo_viewable():
                self.hide_main_window()
            else:
                self.show_main_window()
        except Exception as e:
            logging.error(f"Ошибка переключения окна: {e}")

    def toggle_overlay_from_manager(self):
        """Безопасный вызов переключения оверлея из другого потока."""
        self.root.after(0, self.toggle_overlay)

    def exit_application(self, icon=None, item=None) -> None:
        """Полное завершение приложения."""
        logging.info("Выход из приложения через трей")
        self.force_exit = True
        if self.tray_icon:
            self.tray_icon.stop()
        self.root.after(0, lambda: self.root.quit())
    def on_pixel_design_applied(self) -> None:
        """Обработка применения дизайна пикселей из редактора."""
        logging.info("Применен новый дизайн пикселей")
        self.ui_components.refresh_ui()
        self.overlay_manager.refresh()
    def on_window_mapped(self, event) -> None:
        """Обработка показа главного окна."""
        if event.widget == self.root:
            if self.overlay_manager.hwnd:
                pass
    def on_window_unmapped(self, event) -> None:
        """Обработка скрытия главного окна."""
        pass
    def on_closing(self) -> None:
        """Обработка закрытия главного окна (сворачивание в трей)."""
        if self.force_exit or not TRAY_AVAILABLE:
            self.cleanup()
            return
        logging.info("Сворачивание в системный трей")
        self.hide_main_window()
    def init_resolution(self) -> None:
        """Автоматически определяет и устанавливает начальное разрешение экрана."""
        try:
            width, height = ResolutionDetector.get_resolution()
            if self.settings_manager.set_resolution(width, height):
                logging.info(f"Автоматически определено разрешение: {width}x{height}")
        except Exception as e:
            logging.error(f"Ошибка автоматического определения разрешения: {e}")
    def on_resolution_changed(self, old_res: tuple, new_res: tuple) -> None:
        """Обратный вызов при изменении разрешения экрана."""
        new_width, new_height = new_res
        logging.info(f"Обнаружено изменение разрешения экрана: {new_width}x{new_height}")
        self.settings_manager.set_resolution(new_width, new_height)
        def update_ui():
            if hasattr(self, 'ui_components'):
                self.ui_components.ui_vars['screen_width'].set(new_width)
                self.ui_components.ui_vars['screen_height'].set(new_height)
                self.ui_components.on_resolution_change()
        self.root.after(0, update_ui)
    def cleanup(self) -> None:
        """Очистка ресурсов при закрытии приложения."""
        if self.is_closing:
            return
        self.is_closing = True
        logging.info("Начало процедуры закрытия приложения")
        try:
            if hasattr(self, 'ui_components'):
                self.ui_components.update_settings_from_ui()
            if hasattr(self, 'settings_manager'):
                self.settings_manager.save_settings()
            if hasattr(self, 'pixel_editor') and self.pixel_editor.editor_window:
                try:
                    if self.pixel_editor.editor_window.winfo_exists():
                        self.pixel_editor.editor_window.destroy()
                except:
                    pass
            if hasattr(self, 'overlay_manager'):
                self.overlay_manager.cleanup()
            if self.tray_icon:
                try:
                    self.tray_icon.stop()
                except:
                    pass
            if hasattr(self, 'root'):
                try:
                    self.root.quit()
                    self.root.destroy()
                except:
                    pass
        except Exception as e:
            logging.error(f"Ошибка при закрытии приложения: {e}")
        logging.info("Приложение закрыто")
    def start(self, args):
        """Запуск приложения с учетом аргументов командной строки."""
        # Сворачивание в трей если указано
        start_minimized = args.minimize or self.settings_manager.get('start_minimized')

        if start_minimized and not args.no_tray:
            logging.info("Приложение запущено в свернутом виде")
            self.root.withdraw()  # Сразу скрываем окно
        else:
            if start_minimized and args.no_tray:
                logging.info("Минимизация недоступна при отключенном трее, запускается в обычном режиме")
            self.show_main_window()

    def run(self) -> None:
        """Запуск основного цикла приложения."""
        try:
            logging.info("Запуск основного цикла приложения")
            self.root.mainloop()
        except KeyboardInterrupt:
            logging.info("Приложение прервано пользователем")
            self.force_exit = True
        except Exception as e:
            logging.error(f"Неожиданная ошибка в основном цикле: {e}")
            self.force_exit = True
        finally:
            self.cleanup()
    def show_main_window(self) -> None:
        """Показать главное окно конфигурации."""
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.focus_force()
            if WIN32_AVAILABLE:
                try:
                    hwnd = int(self.root.winfo_id())
                    win32gui.SetWindowPos(hwnd, win32con.HWND_TOPMOST, 0, 0, 0, 0,
                                          win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
                    win32gui.SetWindowPos(hwnd, win32con.HWND_NOTOPMOST, 0, 0, 0, 0,
                                          win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
                except:
                    pass
            logging.info("Показано главное окно")
        except Exception as e:
            logging.error(f"Ошибка показа главного окна: {e}")
    def hide_main_window(self) -> None:
        """Скрыть главное окно конфигурации."""
        try:
            self.root.withdraw()
            logging.info("Скрыто главное окно")
        except Exception as e:
            logging.error(f"Ошибка скрытия главного окна: {e}")
    def toggle_overlay(self, icon=None, item=None) -> None:
        """Переключить видимость прицела-оверлея."""
        try:
            current_state = self.settings_manager.get('enabled', False)
            new_state = not current_state
            self.settings_manager.set('enabled', new_state)
            logging.info(f"Оверлей {'включен' if new_state else 'выключен'}")
            if hasattr(self.ui_components, 'ui_vars') and 'enabled' in self.ui_components.ui_vars:
                self.ui_components.ui_vars['enabled'].set(new_state)
            self.overlay_manager.refresh()
        except Exception as e:
            logging.error(f"Ошибка переключения оверлея: {e}")
    def get_version_info(self) -> str:
        """Получить информацию о версии приложения."""
        return "CrossHud_By_PetyaBlatnoy v2.1"
    def get_status_info(self) -> dict:
        """Получить информацию о текущем состоянии приложения."""
        status = {
            'overlay_enabled': self.settings_manager.get('enabled', False),
            'overlay_visible': (self.overlay_manager.hwnd and
                                self.overlay_manager.is_visible),
            'pixel_editor_open': (self.pixel_editor.editor_window and
                                  self.pixel_editor.editor_window.winfo_exists()),
            'settings_file': self.settings_manager.settings_file,
            'screen_resolution': f"{self.settings_manager.get('screen_width', 1920)}x{self.settings_manager.get('screen_height', 1080)}",
            'overlay_size': self.settings_manager.get('overlay_size', 100),
            'tray_available': TRAY_AVAILABLE,
            'main_window_visible': self.root.winfo_viewable()
        }
        logging.debug(f"Статус приложения: {status}")
        return status