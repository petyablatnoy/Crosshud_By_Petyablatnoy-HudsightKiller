#!/usr/bin/env python3

# -*- coding: utf-8 -*-

"""

Pixel editor for creating custom crosshair designs.

Provides a grid-based editor for precise pixel-level crosshair customization.

"""

import tkinter as tk
from tkinter import ttk, colorchooser, messagebox
from typing import List, Tuple, Optional

class PixelEditor:
    """A pixel-perfect editor for creating custom crosshair designs."""

    def __init__(self, root: tk.Tk, settings_manager, on_apply_callback=None):
        """
        Initialize the pixel editor.

        Args:
            root: Parent tkinter window
            settings_manager: Settings manager instance
            on_apply_callback: Callback function when design is applied
        """
        self.root = root
        self.settings_manager = settings_manager
        self.on_apply_callback = on_apply_callback
        self.editor_window: Optional[tk.Toplevel] = None
        self.canvas: Optional[tk.Canvas] = None

        # Grid settings
        self.grid_size = 41  # 41x41 for detailed customization
        self.pixel_scale = 8  # Scale factor for display

        # Current color for drawing
        self.current_color = "#00FF00"

    def open_editor(self) -> None:
        """Open the pixel editor window."""
        if self.editor_window and self.editor_window.winfo_exists():
            self.editor_window.lift()
            return

        self.create_editor_window()

    def create_editor_window(self) -> None:
        """Create the main editor window."""
        self.editor_window = tk.Toplevel(self.root)
        self.editor_window.title("Pixel Editor")
        self.editor_window.geometry("600x650")
        self.editor_window.resizable(False, False)

        # Color palette section
        self.create_color_controls()

        # Drawing grid
        self.create_drawing_grid()

        # Control buttons
        self.create_control_buttons()

        # Instructions
        self.create_instructions()

        # Load current design
        self.load_current_design()

    def create_color_controls(self) -> None:
        """Create color selection controls."""
        color_frame = ttk.Frame(self.editor_window)
        color_frame.pack(pady=10)

        ttk.Label(color_frame, text="Current Color:").pack(side="left")

        self.color_button = tk.Button(
            color_frame,
            text="Choose",
            bg=self.current_color,
            command=self.choose_color,
            width=10
        )
        self.color_button.pack(side="left", padx=5)

    def create_drawing_grid(self) -> None:
        """Create the drawing grid canvas."""
        grid_frame = ttk.Frame(self.editor_window)
        grid_frame.pack(pady=10)

        canvas_size = self.grid_size * self.pixel_scale
        self.canvas = tk.Canvas(
            grid_frame,
            width=canvas_size,
            height=canvas_size,
            bg="white",
            bd=1,
            relief="solid"
        )
        self.canvas.pack()

        # Bind mouse events
        self.canvas.bind("<Button-1>", self.on_left_click)
        self.canvas.bind("<B1-Motion>", self.on_left_drag)
        self.canvas.bind("<Button-3>", self.on_right_click)
        self.canvas.bind("<B3-Motion>", self.on_right_drag)

        self.draw_grid()

    def create_control_buttons(self) -> None:
        """Create control buttons."""
        control_frame = ttk.Frame(self.editor_window)
        control_frame.pack(pady=10)

        buttons = [
            ("Clear All", self.clear_all),
            ("Apply", self.apply_design),
            ("Close", self.close_editor)
        ]

        for text, command in buttons:
            btn = ttk.Button(control_frame, text=text, command=command)
            btn.pack(side="left", padx=5)

    def create_instructions(self) -> None:
        """Create instruction text."""
        info_label = tk.Label(
            self.editor_window,
            text="ЛКМ - рисовать, ПКМ - стирать\nЦентр отмечен красным крестиком",
            font=("Arial", 9)
        )
        info_label.pack(pady=5)

    def draw_grid(self) -> None:
        """Draw the pixel grid with center marker."""
        self.canvas.delete("all")

        # Draw grid lines
        for i in range(self.grid_size + 1):
            x = i * self.pixel_scale
            self.canvas.create_line(x, 0, x, self.grid_size * self.pixel_scale, fill="lightgray")
            self.canvas.create_line(0, x, self.grid_size * self.pixel_scale, x, fill="lightgray")

        # Mark center with red cross
        center = self.grid_size // 2
        center_x = center * self.pixel_scale + self.pixel_scale // 2
        center_y = center * self.pixel_scale + self.pixel_scale // 2
        self.canvas.create_line(center_x - 5, center_y, center_x + 5, center_y, fill="red", width=2)
        self.canvas.create_line(center_x, center_y - 5, center_x, center_y + 5, fill="red", width=2)

    def choose_color(self) -> None:
        """Open color chooser dialog."""
        color = colorchooser.askcolor(color=self.current_color)
        if color[1]:
            self.current_color = color[1]
            self.color_button.configure(bg=color[1])

    def on_left_click(self, event) -> None:
        """Handle left mouse click - draw pixel."""
        self.draw_pixel_at_pos(event.x, event.y)

    def on_left_drag(self, event) -> None:
        """Handle left mouse drag - draw pixels."""
        self.draw_pixel_at_pos(event.x, event.y)

    def on_right_click(self, event) -> None:
        """Handle right mouse click - erase pixel."""
        self.erase_pixel_at_pos(event.x, event.y)

    def on_right_drag(self, event) -> None:
        """Handle right mouse drag - erase pixels."""
        self.erase_pixel_at_pos(event.x, event.y)

    def draw_pixel_at_pos(self, x: int, y: int) -> None:
        """Draw a pixel at screen position."""
        grid_x = x // self.pixel_scale
        grid_y = y // self.pixel_scale

        if 0 <= grid_x < self.grid_size and 0 <= grid_y < self.grid_size:
            # Remove existing pixel if any
            self.erase_pixel_at_grid(grid_x, grid_y)

            # Draw new pixel
            x1 = grid_x * self.pixel_scale + 1
            y1 = grid_y * self.pixel_scale + 1
            x2 = (grid_x + 1) * self.pixel_scale - 1
            y2 = (grid_y + 1) * self.pixel_scale - 1

            tag = f"pixel_{grid_x}_{grid_y}"
            self.canvas.create_rectangle(
                x1, y1, x2, y2,
                fill=self.current_color,
                outline="",
                tags=tag
            )

    def erase_pixel_at_pos(self, x: int, y: int) -> None:
        """Erase pixel at screen position."""
        grid_x = x // self.pixel_scale
        grid_y = y // self.pixel_scale
        self.erase_pixel_at_grid(grid_x, grid_y)

    def erase_pixel_at_grid(self, grid_x: int, grid_y: int) -> None:
        """Erase pixel at grid coordinates."""
        tag = f"pixel_{grid_x}_{grid_y}"
        self.canvas.delete(tag)

    def clear_all(self) -> None:
        """Clear all pixels from the grid."""
        for x in range(self.grid_size):
            for y in range(self.grid_size):
                self.erase_pixel_at_grid(x, y)

    def load_current_design(self) -> None:
        """Load the current pixel design from settings."""
        self.clear_all()
        custom_pixels = self.settings_manager.get('custom_pixels', [])
        center = self.grid_size // 2

        for pixel_x, pixel_y, color in custom_pixels:
            grid_x = center + pixel_x
            grid_y = center + pixel_y

            if 0 <= grid_x < self.grid_size and 0 <= grid_y < self.grid_size:
                x1 = grid_x * self.pixel_scale + 1
                y1 = grid_y * self.pixel_scale + 1
                x2 = (grid_x + 1) * self.pixel_scale - 1
                y2 = (grid_y + 1) * self.pixel_scale - 1

                tag = f"pixel_{grid_x}_{grid_y}"
                self.canvas.create_rectangle(
                    x1, y1, x2, y2,
                    fill=color,
                    outline="",
                    tags=tag
                )

    def apply_design(self) -> None:
        """Apply the current design to settings."""
        custom_pixels = []
        center = self.grid_size // 2

        for x in range(self.grid_size):
            for y in range(self.grid_size):
                tag = f"pixel_{x}_{y}"
                items = self.canvas.find_withtag(tag)
                if items:
                    color = self.canvas.itemcget(items[0], "fill")
                    pixel_x = x - center
                    pixel_y = y - center
                    custom_pixels.append([pixel_x, pixel_y, color])

        self.settings_manager.set('custom_pixels', custom_pixels)

        if self.on_apply_callback:
            self.on_apply_callback()

        messagebox.showinfo("Success", "Pixel design applied!")

    def close_editor(self) -> None:
        """Close the editor window."""
        if self.editor_window:
            self.editor_window.destroy()