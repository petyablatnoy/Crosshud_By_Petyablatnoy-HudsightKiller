#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Компоненты интерфейса для CrossHud_By_PetyaBlatnoy.
Содержит все элементы пользовательского интерфейса и их управление.
"""

import tkinter as tk
from tkinter import ttk, colorchooser, messagebox, filedialog, simpledialog
from typing import Callable, Any, Optional
import logging
from logger_tab import LoggerTab
import threading
from queue import Queue


class UIComponents:
    """Управляет всеми компонентами интерфейса приложения прицела."""

    def __init__(self, root: tk.Tk, settings_manager, overlay_manager, pixel_editor):
        """
        Инициализация компонентов интерфейса.

        Args:
            root: Главное окно tkinter
            settings_manager: Экземпляр менеджера настроек
            overlay_manager: Экземпляр менеджера оверлея
            pixel_editor: Экземпляр пиксельного редактора
        """
        self.root = root
        self.settings_manager = settings_manager
        self.overlay_manager = overlay_manager
        self.pixel_editor = pixel_editor


        self.guide_window = None

        self.guide_window = None

        # Добавить очередь для thread-safe операций
        self.overlay_command_queue = Queue()
        self.processing_overlay_command = False

        # Переменные интерфейса
        self.ui_vars = {}

        self.setup_main_window()
        self.create_ui()

    def on_toggle_overlay(self) -> None:
        """ИСПРАВЛЕННАЯ обработка переключения оверлея - thread-safe."""
        # Предотвратить множественные одновременные вызовы
        if self.processing_overlay_command:
            logging.warning("Overlay command already in progress, skipping")
            return

        self.processing_overlay_command = True

        try:
            # Обновить настройки из UI синхронно
            self.update_settings_from_ui()
            enabled = self.settings_manager.get('enabled', False)

            logging.info(f"Переключение оверлея: enabled={enabled}")

            # Выполнить операции с оверлеем асинхронно
            def toggle_overlay_async():
                try:
                    if enabled:
                        self.overlay_manager.show()
                        logging.info("Оверлей включен")
                    else:
                        self.overlay_manager.hide()
                        logging.info("Оверлей выключен")
                except Exception as e:
                    logging.error(f"Ошибка переключения оверлея: {e}")
                finally:
                    # Сбросить флаг в главном потоке
                    self.root.after(0, lambda: setattr(self, 'processing_overlay_command', False))

            # Запустить в отдельном потоке
            overlay_thread = threading.Thread(target=toggle_overlay_async, daemon=True)
            overlay_thread.start()

        except Exception as e:
            logging.error(f"Ошибка в on_toggle_overlay: {e}")
            self.processing_overlay_command = False

    def on_setting_change(self, *args) -> None:
        """ИСПРАВЛЕННАЯ обработка изменений настроек - thread-safe."""
        try:
            self.update_settings_from_ui()

            # Обновить оверлей асинхронно
            def refresh_overlay_async():
                try:
                    self.overlay_manager.refresh()
                except Exception as e:
                    logging.error(f"Ошибка обновления оверлея: {e}")

            # Небольшая задержка для накопления изменений
            if hasattr(self, '_setting_change_timer'):
                self._setting_change_timer.cancel()

            self._setting_change_timer = threading.Timer(0.1, refresh_overlay_async)
            self._setting_change_timer.start()

            logging.debug("Настройки обновлены")

        except Exception as e:
            logging.error(f"Ошибка в on_setting_change: {e}")

    def setup_main_window(self) -> None:
        """Настройка главного окна приложения."""
        self.root.title("CrossHud_By_PetyaBlatnoy v2.1")
        self.root.geometry("650x950")
        self.root.resizable(False, False)

        # Настройка иконки и стиля
        try:
            self.root.iconbitmap("icon.ico")
        except:
            pass  # Игнорировать если иконка не найдена

    def create_ui(self) -> None:
        """Создание главного пользовательского интерфейса."""
        # Заголовок приложения
        header_frame = tk.Frame(self.root, bg="#2c3e50", height=60)
        header_frame.pack(fill="x")
        header_frame.pack_propagate(False)

        tk.Label(header_frame, text="CrossHud_By_PetyaBlatnoy",
                 font=("Arial", 16, "bold"), fg="white", bg="#2c3e50").pack(pady=10)
        tk.Label(header_frame, text="Продвинутый прицел-оверлей для игр",
                 font=("Arial", 9), fg="#ecf0f1", bg="#2c3e50").pack()

        # Создание блокнота для вкладок
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill="both", expand=True, padx=10, pady=10)

        # Создание стиля для жирного чекбокса
        style = ttk.Style()
        style.configure("Bold.TCheckbutton", font=("Arial", 12, "bold"))

        # Создание вкладок
        main_frame = ttk.Frame(notebook)
        effects_frame = ttk.Frame(notebook)
        pixel_frame = ttk.Frame(notebook)
        display_frame = ttk.Frame(notebook)
        logger_frame = ttk.Frame(notebook)

        notebook.add(main_frame, text="Основные настройки")
        notebook.add(effects_frame, text="Эффекты")
        notebook.add(pixel_frame, text="Пиксельный редактор")
        notebook.add(display_frame, text="Настройки дисплея")
        notebook.add(logger_frame, text="Журнал событий")

        # Создание содержимого вкладок
        self.create_main_settings(main_frame)
        self.create_effects_settings(effects_frame)
        self.create_pixel_editor_ui(pixel_frame)
        self.create_display_settings(display_frame)

        # Инициализация вкладки логирования
        self.logger_tab = LoggerTab(logger_frame)

        # Кнопки управления
        self.create_control_buttons()

        # Инициализация значений интерфейса
        self.refresh_ui()

        logging.info("Пользовательский интерфейс инициализирован")

    def create_main_settings(self, parent: ttk.Frame) -> None:
        """Создание вкладки основных настроек прицела."""
        title_label = tk.Label(parent, text="Настройки прицела",
                               font=("Arial", 14, "bold"))
        title_label.pack(pady=10)

        # Прокручиваемый фрейм
        canvas_frame = tk.Canvas(parent)
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=canvas_frame.yview)
        scrollable_frame = ttk.Frame(canvas_frame)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas_frame.configure(scrollregion=canvas_frame.bbox("all"))
        )

        canvas_frame.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas_frame.configure(yscrollcommand=scrollbar.set)

        # Включить/выключить прицел
        self.create_checkbox(scrollable_frame, "Включить прицел", 'enabled', self.on_toggle_overlay, style="Bold.TCheckbutton")

        # Слайдеры с точными значениями
        self.create_precision_slider(scrollable_frame, "Размер:", 'size', 0.5, 100.0)
        self.create_precision_slider(scrollable_frame, "Толщина:", 'thickness', 0.1, 15.0)
        self.create_precision_slider(scrollable_frame, "Зазор:", 'gap', 0.0, 30.0)

        # Выбор цвета
        self.create_color_button(scrollable_frame, "Цвет:", 'color')

        # Слайдер прозрачности
        self.create_precision_slider(scrollable_frame, "Прозрачность:", 'opacity', 0.1, 1.0)

        # Настройки обводки
        self.create_checkbox(scrollable_frame, "Включить обводку", 'outline_enabled')
        self.create_precision_slider(scrollable_frame, "Толщина обводки:", 'outline_width', 0.0, 8.0)
        self.create_color_button(scrollable_frame, "Цвет обводки:", 'outline_color')

        # Настройки центральной точки
        self.create_checkbox(scrollable_frame, "Центральная точка", 'center_dot')
        self.create_precision_slider(scrollable_frame, "Размер центральной точки:", 'center_dot_size', 0.1, 10.0)
        self.create_color_button(scrollable_frame, "Цвет центральной точки:", 'center_dot_color')

        # Скрытие по правой кнопке мыши
        self.create_combobox(
            scrollable_frame,
            "Скрытие по ПКМ:",
            'rmb_hide_mode',
            ["Отключено", "Удержание", "Переключение"],
            ["disabled", "hold", "toggle"]
        )

        # Запускать свернуто
        self.create_checkbox(scrollable_frame, "Запускать свернуто", 'start_minimized')

        canvas_frame.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

    def create_effects_settings(self, parent: ttk.Frame) -> None:
        """Создание вкладки настроек визуальных эффектов."""
        title_label = tk.Label(parent, text="Визуальные эффекты",
                               font=("Arial", 14, "bold"))
        title_label.pack(pady=10)

        # Режим радуги
        self.create_checkbox(parent, "Режим радуги", 'rainbow_mode', callback=self.on_toggle_rainbow_mode)

        # Динамический цвет
        self.create_checkbox(parent, "Динамический цвет (следует за мышью)", 'dynamic_color', callback=self.on_toggle_dynamic_color)

        # Информация о эффектах
        info_frame = ttk.LabelFrame(parent, text="Информация")
        info_frame.pack(fill="x", padx=10, pady=20)

        tk.Label(info_frame, text="Режим радуги: прицел меняет цвет радугой",
                 font=("Arial", 9)).pack(anchor="w", padx=10, pady=5)
        tk.Label(info_frame, text="Динамический цвет: цвет зависит от позиции мыши",
                 font=("Arial", 9)).pack(anchor="w", padx=10, pady=5)

    def on_toggle_rainbow_mode(self):
        if self.ui_vars['rainbow_mode'].get():
            if self.ui_vars['dynamic_color'].get():
                messagebox.showinfo(
                    "Автоматическое отключение",
                    "Режим радуги и динамический цвет не могут быть включены одновременно. Динамический цвет был отключен."
                )
                self.ui_vars['dynamic_color'].set(False)
        self.on_setting_change()

    def on_toggle_dynamic_color(self):
        if self.ui_vars['dynamic_color'].get():
            if self.ui_vars['rainbow_mode'].get():
                messagebox.showinfo(
                    "Автоматическое отключение",
                    "Режим радуги и динамический цвет не могут быть включены одновременно. Режим радуги был отключен."
                )
                self.ui_vars['rainbow_mode'].set(False)
        self.on_setting_change()

    def create_pixel_editor_ui(self, parent: ttk.Frame) -> None:
        """Создание интерфейса пиксельного редактора."""
        title_label = tk.Label(parent, text="Пиксельный редактор",
                               font=("Arial", 14, "bold"))
        title_label.pack(pady=10)

        # Описание
        desc_text = """Создавайте уникальные прицелы с точностью до пикселя!
Идеально подходит для профессиональных игроков."""
        tk.Label(parent, text=desc_text, font=("Arial", 10),
                 justify="center").pack(pady=10)

        # Переключатель режима пиксельного редактора
        self.create_checkbox(parent, "Использовать пользовательский пиксельный дизайн", 'pixel_perfect')

        # Кнопка открытия редактора
        editor_btn = ttk.Button(parent, text="Открыть пиксельный редактор",
                                command=self.pixel_editor.open_editor)
        editor_btn.pack(pady=15)

        # Менеджер шаблонов
        self.create_template_manager(parent)

        # Советы по использованию
        tips_frame = ttk.LabelFrame(parent, text="Советы по использованию")
        tips_frame.pack(fill="x", padx=10, pady=10)

        tips_text = """• ЛКМ - рисовать пиксель
• ПКМ - стереть пиксель
• Красный крестик показывает центр прицела"""
        tk.Label(tips_frame, text=tips_text, justify="left",
                 font=("Arial", 9)).pack(padx=10, pady=5)

    def create_template_manager(self, parent: ttk.Frame) -> None:
        """Создание виджета для управления шаблонами."""
        template_frame = ttk.LabelFrame(parent, text="Управление шаблонами")
        template_frame.pack(fill="both", expand=True, padx=10, pady=10)

        list_frame = ttk.Frame(template_frame)
        list_frame.pack(fill="both", expand=True, side="left", padx=5, pady=5)

        self.template_tree = ttk.Treeview(list_frame, columns=("name",), show="headings", height=5)
        self.template_tree.heading("name", text="Название шаблона")
        self.template_tree.pack(fill="both", expand=True, side="left")

        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.template_tree.yview)
        self.template_tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")

        self.template_tree.bind("<<TreeviewSelect>>", self.on_template_select)

        # Кнопки управления
        btn_frame = ttk.Frame(template_frame)
        btn_frame.pack(side="right", fill="y", padx=5)

        buttons = [
            ("Загрузить", self.load_selected_template),
            ("Сохранить новый", self.save_new_template),
            ("Переименовать", self.rename_template),
            ("Удалить", self.delete_template),
            ("Обновить", self.refresh_template_list),
            ("↑", lambda: self.move_template(-1)),
            ("↓", lambda: self.move_template(1)),
            ("Сохранить изменения", self.save_template_changes)
        ]

        for text, command in buttons:
            btn = ttk.Button(btn_frame, text=text, command=command)
            btn.pack(pady=3, fill="x")

        self.populate_template_list()

    def populate_template_list(self):
        """Заполнение списка шаблонов."""
        for i in self.template_tree.get_children():
            self.template_tree.delete(i)
        
        templates = self.settings_manager.get_custom_templates()
        for i, template in enumerate(templates):
            self.template_tree.insert("", "end", iid=str(i), values=(template['name'],))

    def refresh_template_list(self):
        """Обновление списка шаблонов."""
        self.settings_manager.load_custom_templates()
        self.populate_template_list()

    def on_template_select(self, event):
        pass

    def get_selected_template_name(self):
        selection = self.template_tree.selection()
        if not selection:
            messagebox.showwarning("Нет выбора", "Пожалуйста, выберите шаблон из списка.")
            return None
        item_id = selection[0]
        return self.template_tree.item(item_id, "values")[0]

    def load_selected_template(self):
        name = self.get_selected_template_name()
        if name is None:
            return
        
        template = self.settings_manager.get_custom_template_by_name(name)
        if template:
            pixels = template['pixels']
            self.settings_manager.set('custom_pixels', pixels)
            self.overlay_manager.refresh()
            if self.pixel_editor.editor_window and self.pixel_editor.editor_window.winfo_exists():
                self.pixel_editor.load_current_design()
            logging.info(f"Загружен шаблон: {name}")

    def save_new_template(self):
        name = simpledialog.askstring("Новый шаблон", "Введите имя для нового шаблона:")
        if not name:
            return

        templates = self.settings_manager.get_custom_templates()
        if any(t['name'] == name for t in templates):
            messagebox.showerror("Ошибка", "Шаблон с таким именем уже существует.")
            return

        if self.pixel_editor.editor_window and self.pixel_editor.editor_window.winfo_exists():
            self.pixel_editor.apply_design()

        current_pixels = self.settings_manager.get('custom_pixels', [])
        if not current_pixels:
            messagebox.showwarning("Пустой прицел", "Нельзя сохранить пустой прицел как шаблон.")
            return

        if self.settings_manager.save_custom_template(name, current_pixels):
            self.populate_template_list()
            logging.info(f"Сохранен новый шаблон: {name}")
        else:
            messagebox.showerror("Ошибка", f"Не удалось сохранить шаблон {name}")

    def rename_template(self):
        old_name = self.get_selected_template_name()
        if old_name is None:
            return

        new_name = simpledialog.askstring("Переименовать", f"Введите новое имя для '{old_name}':", initialvalue=old_name)

        if not new_name or new_name == old_name:
            return

        templates = self.settings_manager.get_custom_templates()
        if any(t['name'] == new_name for t in templates if t['name'] != old_name):
            messagebox.showerror("Ошибка", "Шаблон с таким именем уже существует.")
            return

        if self.settings_manager.rename_custom_template(old_name, new_name):
            self.populate_template_list()
            # Select the renamed item
            for i, template in enumerate(self.settings_manager.get_custom_templates()):
                if template['name'] == new_name:
                    self.template_tree.selection_set(str(i))
                    break
            logging.info(f"Шаблон '{old_name}' переименован в '{new_name}'")
        else:
            messagebox.showerror("Ошибка", f"Не удалось переименовать шаблон '{old_name}'")

    def delete_template(self):
        name = self.get_selected_template_name()
        if name is None:
            return

        if messagebox.askyesno("Удалить", f"Вы уверены, что хотите удалить шаблон '{name}'?"):
            if self.settings_manager.delete_custom_template(name):
                self.populate_template_list()
                logging.info(f"Удален шаблон: {name}")
            else:
                messagebox.showerror("Ошибка", f"Не удалось удалить шаблон '{name}'")

    def move_template(self, direction):
        # This functionality is not directly supported by file-based templates
        messagebox.showinfo("Информация", "Перемещение шаблонов не поддерживается для файловых шаблонов.")

    def save_template_changes(self):
        name = self.get_selected_template_name()
        if name is None:
            return

        if messagebox.askyesno("Сохранить изменения", f"Вы уверены, что хотите перезаписать шаблон '{name}' текущим дизайном из редактора?"):
            if self.pixel_editor.editor_window and self.pixel_editor.editor_window.winfo_exists():
                self.pixel_editor.apply_design()
                
            current_pixels = self.settings_manager.get('custom_pixels', [])
            if not current_pixels:
                messagebox.showwarning("Пустой прицел", "Нельзя сохранить пустой прицел.")
                return
            
            if self.settings_manager.save_custom_template(name, current_pixels):
                messagebox.showinfo("Сохранено", f"Изменения в шаблоне '{name}' сохранены.")
                logging.info(f"Обновлен шаблон: {name}")
            else:
                messagebox.showerror("Ошибка", f"Не удалось сохранить изменения в шаблоне '{name}'")

    def create_template_buttons(self, parent: ttk.Frame) -> None:
        pass

    def create_display_settings(self, parent: ttk.Frame) -> None:
        """Создание настроек дисплея без автоопределения."""
        title_label = tk.Label(parent, text="Настройки дисплея",
                               font=("Arial", 14, "bold"))
        title_label.pack(pady=10)

        # Ручные настройки разрешения
        manual_frame = ttk.LabelFrame(parent, text="Настройка разрешения")
        manual_frame.pack(fill="x", padx=10, pady=10)

        self.create_spinbox(manual_frame, "Ширина экрана:", 'screen_width', 800, 7680)
        self.create_spinbox(manual_frame, "Высота экрана:", 'screen_height', 600, 4320)
        self.create_spinbox(manual_frame, "Размер области прицела:", 'overlay_size', 50, 500)

        # Предустановки разрешений
        self.create_resolution_presets(parent)

        # Информация о центрировании
        info_frame = ttk.LabelFrame(parent, text="Информация о центрировании")
        info_frame.pack(fill="x", padx=10, pady=10)

        self.center_info_label = tk.Label(info_frame,
                                          text=self.get_center_info(),
                                          font=("Arial", 9))
        self.center_info_label.pack(pady=5)

    def create_resolution_presets(self, parent: ttk.Frame) -> None:
        """Создание кнопок предустановок разрешений."""
        presets_frame = ttk.LabelFrame(parent, text="Предустановки разрешений")
        presets_frame.pack(fill="x", padx=10, pady=10)

        presets = [
            ("1920x1080 (Full HD)", 1920, 1080),
            ("2560x1440 (2K)", 2560, 1440),
            ("3840x2160 (4K)", 3840, 2160),
            ("1366x768 (HD)", 1366, 768),
            ("1600x900 (HD+)", 1600, 900),
            ("2560x1080 (21:9)", 2560, 1080)
        ]

        for i, (name, width, height) in enumerate(presets):
            if i % 2 == 0:
                row_frame = ttk.Frame(presets_frame)
                row_frame.pack(fill="x", pady=2)
            btn = ttk.Button(row_frame, text=name,
                             command=lambda w=width, h=height: self.set_preset_resolution(w, h))
            btn.pack(side="left", padx=5, expand=True, fill="x")

    def create_control_buttons(self) -> None:
        """Создание основных кнопок управления."""
        button_frame = ttk.Frame(self.root)
        button_frame.pack(pady=15)

        # Основные кнопки
        main_buttons = [
            ("Сохранить настройки", self.save_settings, "#27ae60"),
            ("Загрузить настройки", self.load_settings_file, "#3498db"),
            ("Сбросить всё", self.reset_settings, "#e74c3c")
        ]

        for text, command, color in main_buttons:
            btn = tk.Button(button_frame, text=text, command=command,
                            bg=color, fg="white", font=("Arial", 10, "bold"),
                            padx=20, pady=5)
            btn.pack(side="left", padx=5)

        # Дополнительные кнопки
        extra_frame = ttk.Frame(self.root)
        extra_frame.pack(pady=5)

        extra_buttons = [
            ("Показать инструкцию Steam", self.show_steam_guide),
            ("Открыть папку профилей", self.open_profiles_folder)
        ]

        for text, command in extra_buttons:
            btn = ttk.Button(extra_frame, text=text, command=command)
            btn.pack(side="left", padx=5)

    def show_steam_guide(self) -> None:
        """Показать инструкцию по интеграции со Steam, предотвращая дублирование."""
        if self.guide_window and self.guide_window.winfo_exists():
            self.guide_window.lift()
            return

        self.guide_window = tk.Toplevel(self.root)
        self.guide_window.title("Инструкция по интеграции со Steam")
        self.guide_window.geometry("700x600")

        text_widget = tk.Text(self.guide_window, wrap=tk.WORD, font=("Consolas", 10))
        scrollbar = ttk.Scrollbar(self.guide_window, orient="vertical", command=text_widget.yview)
        text_widget.configure(yscrollcommand=scrollbar.set)

        guide_content = self.create_steam_guide_content()
        text_widget.insert("1.0", guide_content)
        text_widget.config(state="disabled")

        text_widget.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        def on_close():
            self.guide_window.destroy()
            self.guide_window = None

        self.guide_window.protocol("WM_DELETE_WINDOW", on_close)

    def create_steam_guide_content(self) -> str:
        """Создание содержимого инструкции Steam."""
        import os
        import sys
        user_profile = os.path.expanduser("~")
        profiles_path = os.path.join(user_profile, "CrossHud_By_PetyaBlatnoy", "profiles")
        
        launch_param = "[ВАША КОМАНДА ЗАПУСКА CROSSHUD] && %command%"

        return f"""
=== ИНСТРУКЦИЯ ПО ИНТЕГРАЦИИ СО STEAM ===

1. АВТОЗАПУСК С ИГРОЙ:
- Откройте Steam
- Найдите нужную игру в библиотеке
- Правый клик по игре → Свойства
- В поле "Параметры запуска" введите:
{launch_param}
(Временно не работает.)

2. НАСТРОЙКА ПРОФИЛЕЙ:
- Запустите CrossHud_By_PetyaBlatnoy
- Настройте прицел под конкретную игру
- Нажмите "Сохранить настройки"
- По желанию переименуйте файл настроек в {profiles_path}

3. ГОРЯЧИЕ КЛАВИШИ:
- ПКМ - Временно скрыть прицел (по умолчанию)

4. СОВЕТЫ ПО ИСПОЛЬЗОВАНИЮ:
- Запускайте игру в полноэкранном режиме
- Отключите встроенный прицел игры

УСТРАНЕНИЕ ПРОБЛЕМ:
- Запускайте от имени администратора
- Проверьте правильность пути в параметрах
- Добавьте в исключения антивируса
"""

    def open_profiles_folder(self) -> None:
        """Открытие папки с профилями."""
        try:
            import os
            profiles_dir = os.path.join(os.path.expanduser("~"), "CrossHud_By_PetyaBlatnoy", "profiles")
            os.makedirs(profiles_dir, exist_ok=True)
            os.startfile(profiles_dir)
            logging.info(f"Открыта папка профилей: {profiles_dir}")
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось открыть папку профилей:\n{e}")
            logging.error(f"Ошибка открытия папки профилей: {e}")
        """Создание виджета флажка."""
        var = tk.BooleanVar(value=self.settings_manager.get(setting_key, False))
        self.ui_vars[setting_key] = var

        command = callback if callback else self.on_setting_change
        cb = ttk.Checkbutton(parent, text=text, variable=var, command=command, style=style)
        cb.pack(anchor="w", pady=5)

    def create_checkbox(self, parent: ttk.Frame, text: str, setting_key: str,
                        callback: Optional[Callable] = None, style: Optional[str] = None) -> None:
        """Создание виджета флажка."""
        var = tk.BooleanVar(value=self.settings_manager.get(setting_key, False))
        self.ui_vars[setting_key] = var

        command = callback if callback else self.on_setting_change
        cb = ttk.Checkbutton(parent, text=text, variable=var, command=command, style=style)
        cb.pack(anchor="w", pady=5)

    def create_combobox(self, parent: ttk.Frame, text: str, setting_key: str,
                        display_values: list, setting_values: list) -> None:
        """Создание выпадающего списка с сопоставлением значений."""
        frame = ttk.Frame(parent)
        frame.pack(fill="x", pady=5)
        ttk.Label(frame, text=text).pack(side="left")

        # Сохранение карт для преобразования
        self.ui_vars[f"{setting_key}_map"] = {display: setting for display, setting in zip(display_values, setting_values)}
        self.ui_vars[f"{setting_key}_inv_map"] = {setting: display for display, setting in zip(display_values, setting_values)}

        var = tk.StringVar()
        self.ui_vars[setting_key] = var

        combo = ttk.Combobox(frame, textvariable=var, values=display_values, state="readonly", width=15)
        combo.pack(side="right", padx=(10, 0))
        
        # Установка начального значения
        current_setting = self.settings_manager.get(setting_key, setting_values[0])
        current_display = self.ui_vars[f"{setting_key}_inv_map"].get(current_setting, display_values[0])
        var.set(current_display)

        combo.bind("<<ComboboxSelected>>", self.on_setting_change)

    def create_precision_slider(self, parent: ttk.Frame, text: str, setting_key: str,
                                min_val: float, max_val: float) -> None:
        """Создание точного слайдера с возможностью ввода значений."""
        frame = ttk.Frame(parent)
        frame.pack(fill="x", pady=5)

        ttk.Label(frame, text=text).pack(side="left")

        # Entry для ввода значения
        var = tk.DoubleVar(value=self.settings_manager.get(setting_key, min_val))
        self.ui_vars[setting_key] = var

        entry = ttk.Entry(frame, textvariable=var, width=8)
        entry.pack(side="right", padx=(5, 0))
        entry.bind('<Return>', lambda e: self.on_entry_change())
        entry.bind('<FocusOut>', lambda e: self.on_entry_change())

        # Scale для визуального изменения
        scale = tk.Scale(frame, from_=min_val, to=max_val,
                         variable=var, orient="horizontal",
                         command=self.on_setting_change,
                         resolution=0.01,
                         showvalue=False, length=200)
        scale.pack(side="right", padx=(10, 5))

    def create_color_button(self, parent: ttk.Frame, text: str, setting_key: str) -> None:
        """Создание кнопки выбора цвета с поддержкой черного."""
        frame = ttk.Frame(parent)
        frame.pack(fill="x", pady=5)

        ttk.Label(frame, text=text).pack(side="left")

        current_color = self.settings_manager.get(setting_key, '#00FF00')
        button = tk.Button(frame, text="Выбрать цвет",
                           bg=current_color,
                           command=lambda: self.choose_color(setting_key, button),
                           width=15, font=("Arial", 9))

        # Специальная обработка для черного цвета в UI
        if current_color.upper() == '#000000':
            button.configure(fg='white')  # Белый текст на черном фоне

        button.pack(side="right")

        # Сохранение ссылки на кнопку для обновления цвета
        self.ui_vars[f"{setting_key}_button"] = button

    def create_spinbox(self, parent: ttk.Frame, text: str, setting_key: str,
                       min_val: int, max_val: int) -> None:
        """Создание виджета числового ввода."""
        frame = ttk.Frame(parent)
        frame.pack(fill="x", pady=5)

        ttk.Label(frame, text=text).pack(side="left")

        var = tk.IntVar(value=self.settings_manager.get(setting_key, min_val))
        self.ui_vars[setting_key] = var

        spinbox = ttk.Spinbox(frame, from_=min_val, to=max_val,
                              textvariable=var,
                              command=self.on_resolution_change, width=10)
        spinbox.bind('<Return>', lambda e: self.on_resolution_change())
        spinbox.bind('<FocusOut>', lambda e: self.on_resolution_change())
        spinbox.pack(side="right")

    # Обработчики событий

    def on_entry_change(self) -> None:
        """Обработка изменения значения в Entry."""
        self.on_setting_change()

    def on_resolution_change(self) -> None:
        """Обработка изменения разрешения с обновлением позиции."""
        self.update_settings_from_ui()

        # Проверяем корректность введенных значений
        width = self.settings_manager.get('screen_width', 1920)
        height = self.settings_manager.get('screen_height', 1080)

        if self.settings_manager.validate_resolution(width, height):
            # Обновляем позицию оверлея
            self.overlay_manager.refresh()

            if hasattr(self, 'center_info_label'):
                self.center_info_label.configure(text=self.get_center_info())

            logging.info(f"Разрешение экрана обновлено: {width}x{height}")
        else:
            logging.warning(f"Некорректное разрешение: {width}x{height}")

    def choose_color(self, setting_key: str, button: tk.Button) -> None:
        """Обработка выбора цвета с поддержкой черного."""
        current_color = self.settings_manager.get(setting_key, '#00FF00')
        color = colorchooser.askcolor(color=current_color, title="Выберите цвет")

        if color[1]:
            selected_color = color[1]

            if selected_color.upper() == '#000000':
                # Для черного цвета в интерфейсе оставляем черный
                self.settings_manager.set(setting_key, '#000000')
                button.configure(bg='#000000', fg='white')  # Белый текст на черном фоне
            else:
                self.settings_manager.set(setting_key, selected_color)
                button.configure(bg=selected_color, fg='black')  # Черный текст на светлом фоне

            self.overlay_manager.refresh()
            logging.info(f"Цвет {setting_key} изменен на {selected_color}")

    def set_preset_resolution(self, width: int, height: int) -> None:
        """Установка предустановленного разрешения с проверкой."""
        if self.settings_manager.set_resolution(width, height):
            self.ui_vars['screen_width'].set(width)
            self.ui_vars['screen_height'].set(height)
            self.on_resolution_change()
            logging.info(f"Установлено разрешение: {width}x{height}")
        else:
            messagebox.showerror("Ошибка", f"Некорректное разрешение: {width}x{height}")

    def get_center_info(self) -> str:
        """Получение текста информации о центрировании."""
        center_x, center_y = self.settings_manager.get_center_position()
        overlay_x, overlay_y, overlay_w, overlay_h = self.settings_manager.get_overlay_position()

        return (f"Центр экрана: ({center_x}, {center_y})\n"
                f"Позиция прицела: ({overlay_x}, {overlay_y})\n"
                f"Область оверлея: {overlay_w}x{overlay_h} пикселей")

    # Методы шаблонов (Удалены, т.к. заменены новым менеджером шаблонов)

    # Управление настройками

    def update_settings_from_ui(self) -> None:
        """Обновление менеджера настроек из значений интерфейса."""
        for key, var in self.ui_vars.items():
            if key.endswith(('_button', '_map', '_inv_map')):
                continue
            
            try:
                value = var.get()
                # Обработка выпадающих списков с сопоставлением
                if f"{key}_map" in self.ui_vars:
                    setting_value = self.ui_vars[f"{key}_map"].get(value)
                    if setting_value:
                        self.settings_manager.set(key, setting_value)
                else:
                    self.settings_manager.set(key, value)
            except tk.TclError:
                pass  # Пропустить неверные значения

    def refresh_ui(self) -> None:
        """Обновление интерфейса текущими значениями настроек."""
        for key, var in self.ui_vars.items():
            if key.endswith(('_button', '_map', '_inv_map')):
                continue

            try:
                current_value = self.settings_manager.get(key)
                if current_value is None:
                    continue

                # Обработка выпадающих списков
                if f"{key}_inv_map" in self.ui_vars:
                    display_value = self.ui_vars[f"{key}_inv_map"].get(current_value)
                    if display_value:
                        var.set(display_value)
                else:
                    var.set(current_value)
            except tk.TclError:
                pass

        # Обновление кнопок цвета
        color_settings = ['color', 'outline_color', 'center_dot_color']
        for setting in color_settings:
            button_key = f"{setting}_button"
            if button_key in self.ui_vars:
                color = self.settings_manager.get(setting, '#00FF00')
                if color.upper() == '#000000':
                    self.ui_vars[button_key].configure(bg='#000000', fg='white')
                else:
                    self.ui_vars[button_key].configure(bg=color, fg='black')

        # Обновление информации о центре
        if hasattr(self, 'center_info_label'):
            self.center_info_label.configure(text=self.get_center_info())

    def save_settings(self) -> None:
        """Сохранение настроек в файл."""
        self.update_settings_from_ui()
        self.overlay_manager.refresh()

        if self.settings_manager.save_settings():
            messagebox.showinfo("Настройки", "Настройки успешно сохранены!")
            logging.info("Настройки сохранены")
        else:
            messagebox.showerror("Ошибка", "Не удалось сохранить настройки!")
            logging.error("Ошибка сохранения настроек")

    def load_settings_file(self) -> None:
        """Загрузка настроек из файла через диалог."""
        filename = filedialog.askopenfilename(
            title="Загрузить настройки",
            filetypes=[("JSON файлы", "*.json"), ("Все файлы", "*.*")]
        )

        if filename:
            if self.settings_manager.load_from_file(filename):
                self.refresh_ui()
                self.overlay_manager.refresh()
                messagebox.showinfo("Настройки", "Настройки успешно загружены!")
                logging.info(f"Настройки загружены из {filename}")
            else:
                messagebox.showerror("Ошибка", "Не удалось загрузить настройки!")
                logging.error(f"Ошибка загрузки настроек из {filename}")

    def reset_settings(self) -> None:
        """Сброс всех настроек к значениям по умолчанию."""
        if messagebox.askyesno("Сброс настроек", "Вы уверены, что хотите сбросить все настройки?"):
            self.settings_manager.reset_to_defaults()
            self.refresh_ui()
            self.overlay_manager.refresh()
            logging.info("Настройки сброшены к значениям по умолчанию")


