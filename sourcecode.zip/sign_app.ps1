$c = "CrossHud_Permanent_Cert"
$f = "dist\CrossHud_By_PetyaBlatnoy\CrossHud_By_PetyaBlatnoy.exe"
$e = "dist\CrossHudCert.cer"
if (-not (Test-Path $f)) { exit }
$s = Get-ChildItem Cert:\LocalMachine\My | Where-Object { $_.Subject -match $c }
if (-not $s) {
    $s = New-SelfSignedCertificate -Type CodeSigningCert -Subject "CN=$c" -CertStoreLocation Cert:\LocalMachine\My -NotAfter (Get-Date).AddYears(100)
}
$r = New-Object System.Security.Cryptography.X509Certificates.X509Store "Root", "LocalMachine"
$r.Open("ReadWrite")
$r.Add($s)
$r.Close()
$p = New-Object System.Security.Cryptography.X509Certificates.X509Store "TrustedPublisher", "LocalMachine"
$p.Open("ReadWrite")
$p.Add($s)
$p.Close()
Set-AuthenticodeSignature -Certificate $s -FilePath $f -TimestampServer "http://timestamp.digicert.com"
Export-Certificate -Cert $s -FilePath $e -Type CERT