#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Надежный детектор разрешения экрана для CrossHud_By_PetyaBlatnoy.
"""
import logging
from typing import Tuple, Optional
class ResolutionDetector:
    """Класс для надежного определения разрешения экрана."""
    @staticmethod
    def get_resolution_winapi() -> Optional[Tuple[int, int]]:
        """Получить разрешение через Windows API."""
        try:
            import ctypes
            user32 = ctypes.windll.user32
            width = user32.GetSystemMetrics(0)
            height = user32.GetSystemMetrics(1)
            if width > 0 and height > 0:
                return width, height
        except Exception as e:
            logging.debug(f"Windows API resolution detection failed: {e}")
        return None
    @staticmethod
    def get_resolution_tkinter() -> Optional[Tuple[int, int]]:
        """Получить разрешение через tkinter."""
        try:
            import tkinter as tk
            root = tk.Tk()
            root.withdraw()
            width = root.winfo_screenwidth()
            height = root.winfo_screenheight()
            root.destroy()
            if width > 0 and height > 0:
                return width, height
        except Exception as e:
            logging.debug(f"Tkinter resolution detection failed: {e}")
        return None
    @staticmethod
    def get_resolution_pygame() -> Optional[Tuple[int, int]]:
        """Получить разрешение через pygame (если доступно)."""
        try:
            import pygame
            pygame.init()
            info = pygame.display.Info()
            pygame.quit()
            width, height = info.current_w, info.current_h
            if width > 0 and height > 0:
                return width, height
        except Exception as e:
            logging.debug(f"Pygame resolution detection failed: {e}")
        return None
    @classmethod
    def get_resolution(self) -> Tuple[int, int]:
        """
        Получить разрешение экрана используя несколько методов.
        Возвращает наиболее надежный результат.
        """
        methods = [
            ("Windows API", self.get_resolution_winapi),
            ("Tkinter", self.get_resolution_tkinter),
            ("Pygame", self.get_resolution_pygame)
        ]
        results = []
        for method_name, method_func in methods:
            try:
                result = method_func()
                if result:
                    results.append((method_name, result))
                    logging.debug(f"{method_name} detected: {result[0]}x{result[1]}")
            except Exception as e:
                logging.debug(f"{method_name} failed: {e}")
        if not results:
            logging.warning("All resolution detection methods failed, using default")
            return 1920, 1080
        if len(set(result[1] for result in results)) == 1:
            width, height = results[0][1]
            logging.info(f"Resolution detected consistently: {width}x{height}")
            return width, height
        from collections import Counter
        counter = Counter(result[1] for result in results)
        most_common = counter.most_common(1)[0][0]
        width, height = most_common
        logging.info(f"Resolution detected (most common): {width}x{height}")
        return width, height
    @classmethod
    def monitor_resolution_changes(cls, callback, interval=2.0):
        """
        Мониторинг изменений разрешения экрана.
        
        Args:
            callback: Функция, вызываемая при изменении разрешения
            interval: Интервал проверки в секундах
        """
        import threading
        import time
        last_resolution = cls.get_resolution()
        def monitor():
            nonlocal last_resolution
            while True:
                try:
                    current_resolution = cls.get_resolution()
                    if current_resolution != last_resolution:
                        logging.info(f"Resolution changed: {last_resolution} -> {current_resolution}")
                        callback(last_resolution, current_resolution)
                        last_resolution = current_resolution
                    time.sleep(interval)
                except Exception as e:
                    logging.error(f"Resolution monitoring error: {e}")
                    time.sleep(interval)
        thread = threading.Thread(target=monitor, daemon=True)
        thread.start()
        return thread