#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Overlay manager for the crosshair overlay window.
Handles the transparent overlay window and crosshair rendering with true click-through.
"""
import tkinter as tk
import math
import colorsys
from threading import Timer, Lock, Event, Thread
from typing import Optional, List, Tuple
import ctypes
from ctypes import wintypes
import time
import logging
import queue
try:
    import win32gui
    import win32con
    import win32api
    WIN32_AVAILABLE = True
except ImportError:
    WIN32_AVAILABLE = False
    print("Warning: win32api not available, some features will be disabled")
user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32
gdi32 = ctypes.windll.gdi32
WS_EX_LAYERED = 0x80000
WS_EX_TRANSPARENT = 0x20
WS_EX_TOPMOST = 0x8
WS_EX_TOOLWINDOW = 0x80
WS_EX_NOACTIVATE = 0x8000000
WS_POPUP = 0x80000000
GWL_EXSTYLE = -20
GWL_STYLE = -16
LWA_COLORKEY = 0x1
LWA_ALPHA = 0x2
HWND_TOPMOST = -1
SWP_NOMOVE = 0x0002
SWP_NOSIZE = 0x0001
SWP_NOACTIVATE = 0x0010
TRANSPARENT_COLOR = 0x000000
class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]
class SIZE(ctypes.Structure):
    _fields_ = [("cx", ctypes.c_long), ("cy", ctypes.c_long)]
class BLENDFUNCTION(ctypes.Structure):
    _fields_ = [("BlendOp", ctypes.c_ubyte),
                ("BlendFlags", ctypes.c_ubyte),
                ("SourceConstantAlpha", ctypes.c_ubyte),
                ("AlphaFormat", ctypes.c_ubyte)]
AC_SRC_OVER = 0
AC_SRC_ALPHA = 1
if ctypes.sizeof(ctypes.c_void_p) == 8:
    LRESULT = ctypes.c_int64
    WPARAM = ctypes.c_uint64
    LPARAM = ctypes.c_int64
    LONG_PTR = ctypes.c_int64
    UINT_PTR = ctypes.c_uint64
else:
    LRESULT = ctypes.c_long
    WPARAM = ctypes.c_uint
    LPARAM = ctypes.c_long
    LONG_PTR = ctypes.c_long
    UINT_PTR = ctypes.c_uint
HWND = ctypes.c_void_p
HINSTANCE = ctypes.c_void_p
HICON = ctypes.c_void_p
HCURSOR = ctypes.c_void_p
HBRUSH = ctypes.c_void_p
LPCWSTR = ctypes.c_wchar_p
WNDPROC = ctypes.WINFUNCTYPE(LRESULT, HWND, wintypes.UINT, WPARAM, LPARAM)
user32.DefWindowProcW.argtypes = [HWND, wintypes.UINT, WPARAM, LPARAM]
user32.DefWindowProcW.restype = LRESULT
user32.CreateWindowExW.argtypes = [
    wintypes.DWORD,
    LPCWSTR,
    LPCWSTR,
    wintypes.DWORD,
    ctypes.c_int,
    ctypes.c_int,
    ctypes.c_int,
    ctypes.c_int,
    HWND,
    wintypes.HANDLE,
    HINSTANCE,
    ctypes.c_void_p
]
user32.CreateWindowExW.restype = HWND
class OverlayManager:
    """Manages the transparent overlay window with true click-through capability."""
    def __init__(self, root: tk.Tk, settings_manager, on_toggle_callback=None):
        """
        Initialize overlay manager.

        Args:
            root: Main tkinter root window
            settings_manager: Settings manager instance
            on_toggle_callback: Callback for toggling overlay visibility
        """
        self.root = root
        self.settings_manager = settings_manager
        self.on_toggle_callback = on_toggle_callback
        self.hwnd = None
        self.hdc = None
        self.hbitmap = None
        self.old_bitmap = None
        self.mem_dc = None
        self.rmb_pressed = False
        self.last_rmb_state = False
        self.rainbow_hue = 0
        self.overlay_size = 100
        self.is_visible = False
        self.cleanup_in_progress = False
        self.monitor_thread = None
        self.render_thread = None
        self.thread_stop_event = Event()
        self.command_queue = queue.Queue()
        self.wnd_proc_ptr = None
        if WIN32_AVAILABLE:
            self.create_layered_window()
            if self.hwnd:
                self.start_monitoring()
                if self.settings_manager.get('enabled', False):
                    self.show()
            else:
                logging.error("Failed to create overlay window")
        else:
            logging.warning("Windows API not available, overlay disabled")
    def create_layered_window(self) -> None:
        """Create a layered window using Windows API for true transparency."""
        try:
            class_name = "CrosshairOverlay"
            def wnd_proc(hwnd, msg, wparam, lparam):
                if msg == 0x0002:
                    return 0
                elif msg == 0x0010:
                    return 0
                return user32.DefWindowProcW(hwnd, msg, wparam, lparam)
            self.wnd_proc_ptr = WNDPROC(wnd_proc)
            class WNDCLASSEX(ctypes.Structure):
                _fields_ = [("cbSize", wintypes.UINT),
                            ("style", wintypes.UINT),
                            ("lpfnWndProc", WNDPROC),
                            ("cbClsExtra", ctypes.c_int),
                            ("cbWndExtra", ctypes.c_int),
                            ("hInstance", HINSTANCE),
                            ("hIcon", HICON),
                            ("hCursor", HCURSOR),
                            ("hbrBackground", HBRUSH),
                            ("lpszMenuName", LPCWSTR),
                            ("lpszClassName", LPCWSTR),
                            ("hIconSm", HICON)]
            wc = WNDCLASSEX()
            wc.cbSize = ctypes.sizeof(WNDCLASSEX)
            wc.style = 0
            wc.lpfnWndProc = self.wnd_proc_ptr
            wc.cbClsExtra = 0
            wc.cbWndExtra = 0
            wc.hInstance = kernel32.GetModuleHandleW(None)
            wc.hIcon = None
            wc.hCursor = None
            wc.hbrBackground = None
            wc.lpszMenuName = None
            wc.lpszClassName = class_name
            wc.hIconSm = None
            atom = user32.RegisterClassExW(ctypes.byref(wc))
            screen_width = self.settings_manager.get('screen_width', 1920)
            screen_height = self.settings_manager.get('screen_height', 1080)
            self.overlay_size = self.settings_manager.get('overlay_size', 100)
            center_x = screen_width // 2 - self.overlay_size // 2
            center_y = screen_height // 2 - self.overlay_size // 2
            center_x = max(-32768, min(32767, center_x))
            center_y = max(-32768, min(32767, center_y))
            self.overlay_size = max(1, min(32767, self.overlay_size))
            self.hwnd = user32.CreateWindowExW(
                WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE,
                class_name,
                "Crosshair",
                WS_POPUP,
                center_x, center_y, self.overlay_size, self.overlay_size,
                None, None, wc.hInstance, None
            )
            if not self.hwnd:
                error = kernel32.GetLastError()
                raise Exception(f"Failed to create window, error code: {error}")
            self.hdc = user32.GetDC(self.hwnd)
            if not self.hdc:
                raise Exception("Failed to get device context")
            self.mem_dc = gdi32.CreateCompatibleDC(self.hdc)
            if not self.mem_dc:
                raise Exception("Failed to create memory DC")
            self.create_drawing_surface()
            logging.info(f"Layered window created successfully at position ({center_x}, {center_y})")
        except Exception as e:
            logging.error(f"Failed to create layered window: {e}")
            self.cleanup_window_resources()
    def cleanup_window_resources(self) -> None:
        """Clean up window resources."""
        if self.mem_dc:
            gdi32.DeleteDC(self.mem_dc)
            self.mem_dc = None
        if self.hdc and self.hwnd:
            user32.ReleaseDC(self.hwnd, self.hdc)
            self.hdc = None
        if self.hwnd:
            user32.DestroyWindow(self.hwnd)
            self.hwnd = None
    def update_overlay_position(self) -> None:
        """Обновление размера оверлея и инициирование перерисовки."""
        if not self.hwnd:
            return
        new_size = self.settings_manager.get('overlay_size', 100)
        if new_size != self.overlay_size:
            self.overlay_size = max(1, min(32767, new_size))
            self.create_drawing_surface()
            logging.info(f"Overlay size updated: {self.overlay_size}")
        self.draw_crosshair()
    def create_drawing_surface(self) -> None:
        """Create drawing surface (bitmap) for the overlay."""
        if not self.hwnd or not self.mem_dc:
            return
        if self.hbitmap and self.old_bitmap:
            gdi32.SelectObject(self.mem_dc, self.old_bitmap)
            gdi32.DeleteObject(self.hbitmap)
        self.hbitmap = gdi32.CreateCompatibleBitmap(self.hdc, self.overlay_size, self.overlay_size)
        if not self.hbitmap:
            logging.error("Failed to create bitmap")
            return
        self.old_bitmap = gdi32.SelectObject(self.mem_dc, self.hbitmap)
        self.clear_drawing_surface()
    def clear_drawing_surface(self) -> None:
        """Clear the drawing surface with transparent background."""
        if not self.mem_dc:
            return
        brush = gdi32.CreateSolidBrush(TRANSPARENT_COLOR)
        rect = wintypes.RECT(0, 0, self.overlay_size, self.overlay_size)
        user32.FillRect(self.mem_dc, ctypes.byref(rect), brush)
        gdi32.DeleteObject(brush)
    def start_monitoring(self) -> None:
        """Запуск мониторинга в отдельных потоках."""
        if not WIN32_AVAILABLE or self.cleanup_in_progress:
            return
        self.monitor_thread = Thread(target=self._mouse_monitor_loop, daemon=True)
        self.monitor_thread.start()
        self.render_thread = Thread(target=self._render_loop, daemon=True)
        self.render_thread.start()
        self.command_thread = Thread(target=self._command_processor, daemon=True)
        self.command_thread.start()
    def _mouse_monitor_loop(self) -> None:
        """Основной цикл мониторинга мыши для режимов удержания и переключения."""
        while not self.thread_stop_event.is_set():
            try:
                if self.cleanup_in_progress:
                    break

                rmb_hide_mode = self.settings_manager.get('rmb_hide_mode', 'disabled')
                if rmb_hide_mode == 'disabled' or not WIN32_AVAILABLE:
                    self.thread_stop_event.wait(0.1)
                    continue

                rmb_state = win32api.GetAsyncKeyState(win32con.VK_RBUTTON)
                rmb_pressed = (rmb_state & 0x8000) != 0

                if rmb_hide_mode == 'hold':
                    enabled = self.settings_manager.get('enabled', False)
                    if enabled and rmb_pressed != self.rmb_pressed:
                        self.rmb_pressed = rmb_pressed
                        if self.rmb_pressed:
                            self.command_queue.put(('hide', None))
                        else:
                            self.command_queue.put(('show', None))
                
                elif rmb_hide_mode == 'toggle':
                    if not rmb_pressed and self.last_rmb_state:
                        if self.on_toggle_callback:
                            self.on_toggle_callback()
                
                self.last_rmb_state = rmb_pressed
                self.thread_stop_event.wait(0.05)

            except Exception as e:
                logging.error(f"Mouse monitoring error: {e}")
                break
    def _render_loop(self) -> None:
        """Основной цикл рендеринга."""
        while not self.thread_stop_event.is_set():
            try:
                if self.cleanup_in_progress:
                    break
                if self.settings_manager.get('rainbow_mode', False):
                    self.rainbow_hue += 5
                    if self.rainbow_hue >= 360:
                        self.rainbow_hue = 0
                should_draw = (self.settings_manager.get('enabled', False) and
                               self.is_visible and
                               not self.cleanup_in_progress and
                               not self.rmb_pressed)
                if should_draw:
                    self.command_queue.put(('draw', None))
                self.thread_stop_event.wait(0.05)
            except Exception as e:
                logging.error(f"Render error: {e}")
                break
    def _command_processor(self) -> None:
        """Обработчик команд из очереди."""
        while not self.thread_stop_event.is_set():
            try:
                try:
                    command, data = self.command_queue.get(timeout=0.1)
                except queue.Empty:
                    continue
                if self.cleanup_in_progress:
                    break
                if command == 'show':
                    self._show_overlay()
                elif command == 'hide':
                    self._hide_overlay()
                elif command == 'draw':
                    self.draw_crosshair()
                elif command == 'refresh':
                    self._refresh_overlay()
            except Exception as e:
                logging.error(f"Command processor error: {e}")
    def _show_overlay(self) -> None:
        """Внутренняя функция показа оверлея."""
        if not self.hwnd or self.cleanup_in_progress:
            return
        try:
            enabled = self.settings_manager.get('enabled', False)
            hide_on_rmb = self.settings_manager.get('hide_on_rmb', True)
            if enabled and (not self.rmb_pressed or not hide_on_rmb):
                self.update_overlay_position()
                result = user32.ShowWindow(self.hwnd, 1)
                self.is_visible = True
                logging.info(f"Overlay shown: result={result}")
                self.draw_crosshair()
        except Exception as e:
            logging.error(f"Error showing overlay: {e}")
    def _hide_overlay(self) -> None:
        """Внутренняя функция сокрытия оверлея."""
        if not self.hwnd or self.cleanup_in_progress:
            return
        try:
            user32.ShowWindow(self.hwnd, 0)
            self.is_visible = False
            logging.info("Overlay hidden")
        except Exception as e:
            logging.error(f"Error hiding overlay: {e}")
    def _refresh_overlay(self) -> None:
        """Внутренняя функция обновления оверлея."""
        if self.cleanup_in_progress:
            return
        self.update_overlay_position()
        if self.settings_manager.get('enabled', False):
            self._show_overlay()
        else:
            self._hide_overlay()
    def show(self) -> None:
        """Показать оверлей через очередь команд."""
        if not self.cleanup_in_progress:
            self.command_queue.put(('show', None))
    def hide(self) -> None:
        """Скрыть оверлей через очередь команд."""
        if not self.cleanup_in_progress:
            self.command_queue.put(('hide', None))
    def refresh(self) -> None:
        """Обновить оверлей через очередь команд."""
        if not self.cleanup_in_progress:
            self.command_queue.put(('refresh', None))
    def hsv_to_rgb(self, h: float, s: float, v: float) -> Tuple[int, int, int]:
        """Convert HSV to RGB values (0-255)."""
        r, g, b = colorsys.hsv_to_rgb(h / 360.0, s, v)
        return (int(r * 255), int(g * 255), int(b * 255))
    def get_dynamic_color(self) -> Tuple[int, int, int]:
        """Get dynamic color based on mouse position."""
        if not WIN32_AVAILABLE:
            return self.hex_to_rgb(self.settings_manager.get('color', '#00FF00'))
        try:
            cursor_pos = win32gui.GetCursorPos()
            screen_width = self.settings_manager.get('screen_width', 1920)
            hue = (cursor_pos[0] / screen_width) * 360
            return self.hsv_to_rgb(hue, 1.0, 1.0)
        except:
            return self.hex_to_rgb(self.settings_manager.get('color', '#00FF00'))
    def hex_to_rgb(self, hex_color: str) -> Tuple[int, int, int]:
        """Convert hex color to RGB tuple."""
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))
    def rgb_to_colorref(self, r: int, g: int, b: int) -> int:
        """Convert RGB to Windows COLORREF."""
        return r | (g << 8) | (b << 16)
    def get_current_color(self) -> Tuple[int, int, int]:
        """Get the current crosshair color based on active effects."""
        if self.settings_manager.get('rainbow_mode', False):
            return self.hsv_to_rgb(self.rainbow_hue, 1.0, 1.0)
        elif self.settings_manager.get('dynamic_color', False):
            return self.get_dynamic_color()
        else:
            return self.hex_to_rgb(self.settings_manager.get('color', '#00FF00'))
    def draw_crosshair(self) -> None:
        """Отрисовка прицела."""
        if not self.hwnd or not self.mem_dc or not self.is_visible or self.cleanup_in_progress:
            return
        try:
            self.clear_drawing_surface()
            center_x = self.overlay_size // 2
            center_y = self.overlay_size // 2
            if (self.settings_manager.get('pixel_perfect', False) and
                    self.settings_manager.get('custom_pixels', [])):
                self.draw_custom_pixels_gdi(center_x, center_y)
            else:
                main_color = self.get_current_color()
                size = self.settings_manager.get('size', 20.0)
                thickness = self.settings_manager.get('thickness', 2.0)
                gap = self.settings_manager.get('gap', 4.0)
                cos_a, sin_a = 1, 0
                outline_enabled = self.settings_manager.get('outline_enabled', False)
                outline_width = self.settings_manager.get('outline_width', 1.0)
                if outline_enabled and outline_width > 0:
                    outline_color = self.hex_to_rgb(self.settings_manager.get('outline_color', '#000000'))
                    self.draw_cross_outline_gdi(center_x, center_y, size, thickness,
                                                gap, outline_width, outline_color, cos_a, sin_a)
                self.draw_cross_gdi(center_x, center_y, size, thickness, gap, main_color, cos_a, sin_a)
                if self.settings_manager.get('center_dot', False):
                    dot_size = self.settings_manager.get('center_dot_size', 2.0)
                    dot_color = self.hex_to_rgb(self.settings_manager.get('center_dot_color', '#FF0000'))
                    if self.settings_manager.get('rainbow_mode', False):
                        dot_color = self.hsv_to_rgb((self.rainbow_hue + 180) % 360, 1.0, 1.0)
                    outline_enabled = self.settings_manager.get('outline_enabled', False)
                    outline_width = self.settings_manager.get('outline_width', 1.0)
                    if outline_enabled and outline_width > 0:
                        dot_outline_size = int(dot_size) + int(outline_width)
                        outline_color = self.hex_to_rgb(self.settings_manager.get('outline_color', '#000000'))
                        self.draw_circle_gdi(center_x, center_y, dot_outline_size, outline_color)
                    self.draw_circle_gdi(center_x, center_y, int(dot_size), dot_color)
            self.update_layered_window()
        except Exception as e:
            logging.error(f"Error drawing crosshair: {e}")
    def draw_cross_outline_gdi(self, center_x: int, center_y: int, size: float, thickness: float,
                               gap: float, outline_width: float, outline_color: Tuple[int, int, int],
                               cos_a: float, sin_a: float) -> None:
        """Полностью исправленная обводка с правильными углами и поддержкой черного цвета."""
        half_size = int(size // 2)
        thick = max(1, int(thickness))
        gap_int = int(gap)
        outline_w = max(1, int(outline_width))
        thick_half = thick // 2
        if outline_color == (0, 0, 0):
            actual_outline_color = (1, 1, 1)
        else:
            actual_outline_color = outline_color
        main_cross_pixels = set()
        for x_offset in range(-half_size, half_size + 1):
            if abs(x_offset) <= gap_int:
                continue
            for thick_offset in range(-thick_half, thick_half + 1):
                main_cross_pixels.add((center_x + x_offset, center_y + thick_offset))
        for y_offset in range(-half_size, half_size + 1):
            if abs(y_offset) <= gap_int:
                continue
            for thick_offset in range(-thick_half, thick_half + 1):
                main_cross_pixels.add((center_x + thick_offset, center_y + y_offset))
        outline_pixels = set()
        for main_x, main_y in main_cross_pixels:
            for dx in range(-outline_w, outline_w + 1):
                for dy in range(-outline_w, outline_w + 1):
                    if dx == 0 and dy == 0:
                        continue
                    outline_x = main_x + dx
                    outline_y = main_y + dy
                    if (outline_x, outline_y) not in main_cross_pixels:
                        outline_pixels.add((outline_x, outline_y))
        for x, y in outline_pixels:
            self.draw_pixel_gdi(x, y, actual_outline_color)
    def draw_custom_pixels_gdi(self, center_x: int, center_y: int) -> None:
        """Draw custom pixel design using GDI."""
        custom_pixels = self.settings_manager.get('custom_pixels', [])
        for pixel_x, pixel_y, color_hex in custom_pixels:
            x = center_x + pixel_x
            y = center_y + pixel_y
            if self.settings_manager.get('rainbow_mode', False):
                distance = abs(pixel_x) + abs(pixel_y)
                hue = (self.rainbow_hue + distance * 10) % 360
                color = self.hsv_to_rgb(hue, 1.0, 1.0)
            elif (self.settings_manager.get('dynamic_color', False) and
                  color_hex == self.settings_manager.get('color', '#00FF00')):
                color = self.get_dynamic_color()
            else:
                color = self.hex_to_rgb(color_hex)
            self.draw_pixel_gdi(x, y, color)
    def draw_pixel_gdi(self, x: int, y: int, color: Tuple[int, int, int]) -> None:
        """Рисование пикселя с поддержкой черного цвета."""
        if 0 <= x < self.overlay_size and 0 <= y < self.overlay_size:
            if color == (0, 0, 0):
                colorref = self.rgb_to_colorref(1, 1, 1)
            elif color == (1, 1, 1):
                colorref = self.rgb_to_colorref(1, 1, 1)
            else:
                colorref = self.rgb_to_colorref(*color)
            gdi32.SetPixel(self.mem_dc, x, y, colorref)
    def draw_circle_gdi(self, center_x: int, center_y: int, radius: int, color: Tuple[int, int, int]) -> None:
        """Draw a filled circle using GDI with pixel-perfect rendering."""
        if radius <= 1:
            if radius <= 0:
                self.draw_pixel_gdi(center_x, center_y, color)
            else:
                for dx in range(-1, 2):
                    for dy in range(-1, 2):
                        if abs(dx) + abs(dy) <= 1:
                            self.draw_pixel_gdi(center_x + dx, center_y + dy, color)
        else:
            colorref = self.rgb_to_colorref(*color)
            brush = gdi32.CreateSolidBrush(colorref)
            old_brush = gdi32.SelectObject(self.mem_dc, brush)
            pen = gdi32.CreatePen(0, 1, colorref)
            old_pen = gdi32.SelectObject(self.mem_dc, pen)
            gdi32.Ellipse(self.mem_dc, center_x - radius, center_y - radius,
                          center_x + radius + 1, center_y + radius + 1)
            gdi32.SelectObject(self.mem_dc, old_brush)
            gdi32.SelectObject(self.mem_dc, old_pen)
            gdi32.DeleteObject(brush)
            gdi32.DeleteObject(pen)
    def draw_cross_gdi(self, center_x: int, center_y: int, size: float, thickness: float,
                       gap: float, color: Tuple[int, int, int], cos_a: float, sin_a: float) -> None:
        """Базовая отрисовка креста с равномерным распределением толщины."""
        half_size = int(size // 2)
        thick = max(1, int(thickness))
        gap_int = int(gap)
        thick_half = thick // 2
        for x_offset in range(-half_size, half_size + 1):
            if abs(x_offset) <= gap_int:
                continue
            x = center_x + x_offset
            for thick_offset in range(-thick_half, thick_half + 1):
                y = center_y + thick_offset
                self.draw_pixel_gdi(x, y, color)
        for y_offset in range(-half_size, half_size + 1):
            if abs(y_offset) <= gap_int:
                continue
            y = center_y + y_offset
            for thick_offset in range(-thick_half, thick_half + 1):
                x = center_x + thick_offset
                self.draw_pixel_gdi(x, y, color)
    def update_layered_window(self) -> None:
        """Обновление layered window с правильной обработкой черного цвета."""
        if not self.hwnd or not self.mem_dc:
            return
        try:
            screen_width = self.settings_manager.get('screen_width', 1920)
            screen_height = self.settings_manager.get('screen_height', 1080)
            center_x = screen_width // 2 - self.overlay_size // 2
            center_y = screen_height // 2 - self.overlay_size // 2
            window_pos = POINT(center_x, center_y)
            window_size = SIZE(self.overlay_size, self.overlay_size)
            source_pos = POINT(0, 0)
            blend = BLENDFUNCTION()
            blend.BlendOp = AC_SRC_OVER
            blend.BlendFlags = 0
            blend.SourceConstantAlpha = int(self.settings_manager.get('opacity', 1.0) * 255)
            blend.AlphaFormat = 0
            TRANSPARENT_COLOR_KEY = 0x000000
            result = user32.UpdateLayeredWindow(
                self.hwnd,
                self.hdc,
                ctypes.byref(window_pos),
                ctypes.byref(window_size),
                self.mem_dc,
                ctypes.byref(source_pos),
                TRANSPARENT_COLOR_KEY,
                ctypes.byref(blend),
                LWA_COLORKEY | LWA_ALPHA
            )
            if not result:
                error = kernel32.GetLastError()
                logging.debug(f"UpdateLayeredWindow failed with error: {error}")
        except Exception as e:
            logging.error(f"Error updating layered window: {e}")
    def cleanup(self) -> None:
        """Исправленная очистка ресурсов с правильной остановкой потоков."""
        if self.cleanup_in_progress:
            return
        logging.info("Начало очистки overlay manager")
        self.cleanup_in_progress = True
        self.thread_stop_event.set()
        if self.hwnd:
            try:
                user32.ShowWindow(self.hwnd, 0)
                self.is_visible = False
            except:
                pass
        threads_to_wait = []
        if self.monitor_thread and self.monitor_thread.is_alive():
            threads_to_wait.append(self.monitor_thread)
        if self.render_thread and self.render_thread.is_alive():
            threads_to_wait.append(self.render_thread)
        if hasattr(self, 'command_thread') and self.command_thread.is_alive():
            threads_to_wait.append(self.command_thread)
        for thread in threads_to_wait:
            try:
                thread.join(timeout=1.0)
            except:
                pass
        try:
            while not self.command_queue.empty():
                self.command_queue.get_nowait()
        except:
            pass
        if self.hbitmap and self.old_bitmap:
            try:
                gdi32.SelectObject(self.mem_dc, self.old_bitmap)
                gdi32.DeleteObject(self.hbitmap)
                self.hbitmap = None
                self.old_bitmap = None
            except:
                pass
        self.cleanup_window_resources()
        logging.info("Очистка overlay manager завершена")