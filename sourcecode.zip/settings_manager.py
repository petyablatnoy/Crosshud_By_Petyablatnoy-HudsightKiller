#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Thread-safe settings manager без автоопределения разрешения
"""
import json
import os
from typing import Dict, Any, Optional, Tuple
from threading import Lock
import logging
class SettingsManager:
    """Thread-safe settings manager без автоопределения разрешения."""
    DEFAULT_SETTINGS = {
        'enabled': False,
        'size': 20.0,
        'thickness': 2.0,
        'gap': 4.0,
        'color': '#00FF00',
        'opacity': 1.0,
        'outline_enabled': False,
        'outline_color': '#000000',
        'outline_width': 1.0,
        'rmb_hide_mode': 'hold',  # disabled, hold, toggle
        'rainbow_mode': False,
        'pixel_perfect': False,
        'custom_pixels': [],
        'center_dot': False,
        'center_dot_size': 2.0,
        'center_dot_color': '#FF0000',
        'dynamic_color': False,
        'screen_width': 1920,
        'screen_height': 1080,
        'overlay_size': 100,
        'custom_templates': [
            {
                "name": "Шаблон 1 (крест)",
                "pixels": [
                    [-8, 0, '#00FF00'], [-7, 0, '#00FF00'], [-6, 0, '#00FF00'], [-5, 0, '#00FF00'],
                    [-4, 0, '#00FF00'], [-3, 0, '#00FF00'], [-2, 0, '#00FF00'],
                    [2, 0, '#00FF00'], [3, 0, '#00FF00'], [4, 0, '#00FF00'], [5, 0, '#00FF00'],
                    [6, 0, '#00FF00'], [7, 0, '#00FF00'], [8, 0, '#00FF00'],
                    [0, -8, '#00FF00'], [0, -7, '#00FF00'], [0, -6, '#00FF00'], [0, -5, '#00FF00'],
                    [0, -4, '#00FF00'], [0, -3, '#00FF00'], [0, -2, '#00FF00'],
                    [0, 2, '#00FF00'], [0, 3, '#00FF00'], [0, 4, '#00FF00'], [0, 5, '#00FF00'],
                    [0, 6, '#00FF00'], [0, 7, '#00FF00'], [0, 8, '#00FF00'],
                    [0, 0, '#FF0000']
                ]
            },
            {
                "name": "Шаблон 2 (точка)",
                "pixels": [
                    [-3, 0, '#FFFFFF'], [-2, 0, '#FFFFFF'],
                    [2, 0, '#FFFFFF'], [3, 0, '#FFFFFF'],
                    [0, -3, '#FFFFFF'], [0, -2, '#FFFFFF'],
                    [0, 2, '#FFFFFF'], [0, 3, '#FFFFFF'],
                    [-4, 0, '#000000'], [-1, 0, '#000000'], [1, 0, '#000000'], [4, 0, '#000000'],
                    [0, -4, '#000000'], [0, -1, '#000000'], [0, 1, '#000000'], [0, 4, '#000000'],
                    [0, 0, '#00FFFF']
                ]
            },
            {
                "name": "Шаблон 3 (диагональ)",
                "pixels": [
                    [0, 0, '#FF0000'],
                    [-2, -2, '#00FF00'], [-1, -1, '#00FF00'],
                    [1, 1, '#00FF00'], [2, 2, '#00FF00'],
                    [-2, 2, '#00FF00'], [-1, 1, '#00FF00'],
                    [1, -1, '#00FF00'], [2, -2, '#00FF00'],
                ]
            }
        ]
    }
    def __init__(self, settings_file: str = 'crosshair_settings.json'):
        """Initialize thread-safe settings manager."""
        self.settings_file = settings_file
        self.settings = self.DEFAULT_SETTINGS.copy()
        self.lock = Lock()
        self.load_settings()
    def load_settings(self) -> bool:
        """Thread-safe загрузка настроек."""
        try:
            if os.path.exists(self.settings_file):
                with open(self.settings_file, 'r', encoding='utf-8') as f:
                    saved_settings = json.load(f)
                with self.lock:
                    self.settings.update(saved_settings)
                logging.info(f"Settings loaded from {self.settings_file}")
                return True
        except Exception as e:
            logging.error(f"Failed to load settings: {e}")
            return False
    def save_settings(self) -> bool:
        """Thread-safe сохранение настроек."""
        try:
            with self.lock:
                settings_copy = self.settings.copy()
            with open(self.settings_file, 'w', encoding='utf-8') as f:
                json.dump(settings_copy, f, indent=2, ensure_ascii=False)
            logging.info(f"Settings saved to {self.settings_file}")
            return True
        except Exception as e:
            logging.error(f"Failed to save settings: {e}")
            return False
    def load_from_file(self, filepath: str) -> bool:
        """Thread-safe загрузка из указанного файла."""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                loaded_settings = json.load(f)
            with self.lock:
                self.settings.update(loaded_settings)
            logging.info(f"Settings loaded from {filepath}")
            return True
        except Exception as e:
            logging.error(f"Failed to load settings from {filepath}: {e}")
            return False
    def reset_to_defaults(self) -> None:
        """Thread-safe сброс к настройкам по умолчанию."""
        with self.lock:
            self.settings = self.DEFAULT_SETTINGS.copy()
        logging.info("Settings reset to defaults")
    def validate_resolution(self, width: int, height: int) -> bool:
        """Проверка корректности разрешения."""
        return (800 <= width <= 7680 and
                600 <= height <= 4320 and
                width > 0 and height > 0)
    def set_resolution(self, width: int, height: int) -> bool:
        """Установка разрешения с проверкой."""
        if not self.validate_resolution(width, height):
            logging.warning(f"Некорректное разрешение: {width}x{height}")
            return False
        with self.lock:
            old_width = self.settings.get('screen_width', 1920)
            old_height = self.settings.get('screen_height', 1080)
            self.settings['screen_width'] = width
            self.settings['screen_height'] = height
        logging.info(f"Разрешение изменено с {old_width}x{old_height} на {width}x{height}")
        return True
    def get_center_position(self) -> Tuple[int, int]:
        """Получить центральную позицию экрана."""
        width = self.get('screen_width', 1920)
        height = self.get('screen_height', 1080)
        return width // 2, height // 2
    def get_overlay_position(self) -> Tuple[int, int, int, int]:
        """Получить позицию и размер области оверлея."""
        screen_width = self.get('screen_width', 1920)
        screen_height = self.get('screen_height', 1080)
        overlay_size = self.get('overlay_size', 100)
        center_x = screen_width // 2 - overlay_size // 2
        center_y = screen_height // 2 - overlay_size // 2
        center_x = max(0, min(screen_width - overlay_size, center_x))
        center_y = max(0, min(screen_height - overlay_size, center_y))
        return center_x, center_y, overlay_size, overlay_size
    def get(self, key: str, default: Any = None) -> Any:
        """Thread-safe получение значения настройки."""
        with self.lock:
            return self.settings.get(key, default)
    def set(self, key: str, value: Any) -> None:
        """Thread-safe установка значения настройки."""
        with self.lock:
            self.settings[key] = value
    def update(self, new_settings: Dict[str, Any]) -> None:
        """Thread-safe обновление множественных настроек."""
        with self.lock:
            self.settings.update(new_settings)
    def get_all(self) -> Dict[str, Any]:
        """Thread-safe получение всех настроек."""
        with self.lock:
            return self.settings.copy()
    def export_settings(self, filepath: str) -> bool:
        """Экспорт настроек в указанный файл."""
        try:
            with self.lock:
                settings_copy = self.settings.copy()
            export_data = {
                'metadata': {
                    'version': '2.1',
                    'export_time': __import__('datetime').datetime.now().isoformat(),
                    'resolution': f"{settings_copy['screen_width']}x{settings_copy['screen_height']}"
                },
                'settings': settings_copy
            }
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)
            logging.info(f"Settings exported to {filepath}")
            return True
        except Exception as e:
            logging.error(f"Failed to export settings to {filepath}: {e}")
            return False
    def import_settings(self, filepath: str) -> bool:
        """Импорт настроек из файла."""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                import_data = json.load(f)
            if isinstance(import_data, dict) and 'settings' in import_data:
                settings_to_import = import_data['settings']
                metadata = import_data.get('metadata', {})
                logging.info(f"Importing settings with metadata: {metadata}")
            else:
                settings_to_import = import_data
            with self.lock:
                self.settings.update(settings_to_import)
            logging.info(f"Settings imported from {filepath}")
            return True
        except Exception as e:
            logging.error(f"Failed to import settings from {filepath}: {e}")
            return False