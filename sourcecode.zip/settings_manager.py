import json
import os
import sys
import logging
import shutil
from typing import Dict, Any, Optional, Tuple
from threading import Lock

class SettingsManager:
    CURRENT_VERSION = "3.0"
    DEFAULT_SETTINGS = {
        'version': CURRENT_VERSION,
        'enabled': True,
        'size': 20.0,
        'thickness': 2.0,
        'gap': 4.0,
        'color': '#00FF00',
        'opacity': 1.0,
        'outline_enabled': False,
        'outline_color': '#000000',
        'outline_width': 1.0,
        'rmb_hide_mode': 'hold',
        'rainbow_mode': False,
        'pixel_perfect': False,
        'custom_pixels': [],
        'center_dot': False,
        'center_dot_size': 2.0,
        'center_dot_color': '#FF0000',
        'dynamic_color': False,
        'screen_width': 1920,
        'screen_height': 1080,
        'overlay_size': 50,
        'hotkey': 'Insert',
        'autostart': False,
        'start_minimized': False
    }

    def __init__(self, settings_file: Optional[str] = None):
        self.lock = Lock()
        self.settings = self.DEFAULT_SETTINGS.copy()
        self.settings['custom_templates'] = [] 
        self.app_data_dir = os.path.join(os.path.expanduser("~"), "CrossHud_By_PetyaBlatnoy")
        self.profiles_dir = os.path.join(self.app_data_dir, "profiles")
        self.is_profile_load = bool(settings_file)
        if self.is_profile_load:
            self.settings_file = settings_file
            self.load_from_file(settings_file)
        else:
            os.makedirs(self.app_data_dir, exist_ok=True)
            os.makedirs(self.profiles_dir, exist_ok=True)
            self.settings_file = os.path.join(self.app_data_dir, 'settings.json')
            self._initialize_settings()

    def _initialize_settings(self):
        if os.path.exists(self.settings_file):
            self.load_settings()
        else:
            self._try_migrate_old_config()
            self.save_settings()
        self.load_templates_from_disk()

    def _try_migrate_old_config(self):
        old_filename = 'crosshair_settings.json'
        possible_paths = [os.path.join(self.app_data_dir, old_filename), old_filename]
        found_old_config = next((p for p in possible_paths if os.path.exists(p)), None)
        if found_old_config:
            try:
                with open(found_old_config, 'r', encoding='utf-8') as f:
                    old_data = json.load(f)
                self.settings.update(old_data)
                os.rename(found_old_config, found_old_config + ".old")
            except: pass

    def load_settings(self) -> bool:
        try:
            if os.path.exists(self.settings_file):
                with open(self.settings_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                with self.lock: self.settings.update(data)
                return True
        except: pass
        return False

    def load_templates_from_disk(self):
        templates = []
        if os.path.exists(self.profiles_dir):
            for filename in os.listdir(self.profiles_dir):
                if filename.endswith(".json"):
                    try:
                        with open(os.path.join(self.profiles_dir, filename), 'r', encoding='utf-8') as f:
                            t_data = json.load(f)
                            if 'name' in t_data and 'pixels' in t_data:
                                t_data['_filename'] = filename 
                                templates.append(t_data)
                    except: pass
        with self.lock: self.settings['custom_templates'] = templates

    def save_template(self, template_data: Dict[str, Any]) -> str:
        name = template_data.get('name', 'Unnamed')
        safe_name = "".join(c for c in name if c.isalnum() or c in (' ', '-', '_')).strip()
        if not safe_name: safe_name = "template"
        filename = template_data.get('_filename') or f"{safe_name}.json"
        filepath = os.path.join(self.profiles_dir, filename)
        save_data = {"name": name, "pixels": template_data.get('pixels', [])}
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(save_data, f, indent=2, ensure_ascii=False)
            return filename
        except: return ""

    def delete_template(self, template_data: Dict[str, Any]) -> bool:
        filename = template_data.get('_filename')
        if not filename: return False
        filepath = os.path.join(self.profiles_dir, filename)
        if os.path.exists(filepath):
            try:
                os.remove(filepath)
                return True
            except: return False
        return False

    def save_settings(self) -> bool:
        if self.is_profile_load: return True
        try:
            with self.lock:
                settings_data = {k: v for k, v in self.settings.items() if k not in ['custom_templates', 'custom_pixels']}
                settings_data['version'] = self.CURRENT_VERSION
            with open(self.settings_file, 'w', encoding='utf-8') as f:
                json.dump(settings_data, f, indent=2, ensure_ascii=False)
            return True
        except: return False

    def load_from_file(self, filepath: str) -> bool:
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                loaded_settings = json.load(f)
            with self.lock: self.settings.update(loaded_settings)
            return True
        except: return False

    def set_resolution(self, width: int, height: int) -> bool:
        if not (800 <= width <= 7680 and 600 <= height <= 4320): return False
        with self.lock:
            self.settings['screen_width'] = width
            self.settings['screen_height'] = height
        return True

    def get(self, key: str, default: Any = None) -> Any:
        with self.lock: return self.settings.get(key, default)

    def set(self, key: str, value: Any) -> None:
        with self.lock: self.settings[key] = value