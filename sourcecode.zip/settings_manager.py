#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Thread-safe settings manager без автоопределения разрешения
"""
import json
import os
from typing import Dict, Any, Optional, Tuple, List
from threading import Lock
import logging
class SettingsManager:
    """Thread-safe settings manager без автоопределения разрешения."""
    DEFAULT_SETTINGS = {
        'enabled': False,
        'size': 20.0,
        'thickness': 2.0,
        'gap': 4.0,
        'color': '#00FF00',
        'opacity': 1.0,
        'outline_enabled': False,
        'outline_color': '#000000',
        'outline_width': 1.0,
        'rmb_hide_mode': 'hold',  # disabled, hold, toggle
        'rainbow_mode': False,
        'pixel_perfect': False,
        'custom_pixels': [],
        'center_dot': False,
        'center_dot_size': 2.0,
        'center_dot_color': '#FF0000',
        'dynamic_color': False,
        'screen_width': 1920,
        'screen_height': 1080,
        'overlay_size': 100,
        'start_minimized': False,
    }
    def __init__(self, settings_file: str = 'crosshair_settings.json'):
        """Initialize thread-safe settings manager."""
        self.settings_file = settings_file
        self.settings = self.DEFAULT_SETTINGS.copy()
        self.lock = Lock()
        self.profiles_dir = os.path.join(os.path.expanduser("~"), "CrossHud_By_PetyaBlatnoy", "profiles")
        logging.debug(f"Settings file path: {os.path.abspath(self.settings_file)}")
        logging.debug(f"Profiles directory path: {os.path.abspath(self.profiles_dir)}")
        os.makedirs(self.profiles_dir, exist_ok=True)
        self.load_settings()
        self._custom_templates = [] # This will store loaded templates
        self.load_custom_templates()

    def load_custom_templates(self) -> None:
        """Load custom pixel templates from the profiles directory."""
        self._custom_templates = []
        logging.debug(f"Attempting to load custom templates from directory: {os.path.abspath(self.profiles_dir)}")
        if not os.path.exists(self.profiles_dir):
            logging.debug(f"Profiles directory does not exist, creating: {os.path.abspath(self.profiles_dir)}")
            os.makedirs(self.profiles_dir)
            self._create_default_templates()

        for filename in os.listdir(self.profiles_dir):
            if filename.endswith(".json"):
                filepath = os.path.join(self.profiles_dir, filename)
                logging.debug(f"Attempting to load custom template from file: {os.path.abspath(filepath)}")
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        template_data = json.load(f)
                    if "name" in template_data and "pixels" in template_data:
                        self._custom_templates.append(template_data)
                except Exception as e:
                    logging.error(f"Failed to load custom template from {filepath}: {e}")
        logging.info(f"Loaded {len(self._custom_templates)} custom templates.")

    def _create_default_templates(self) -> None:
        """Create default custom templates if the profiles directory is empty."""
        default_templates_data = [
            {
                "name": "Шаблон 1 (крест)",
                "pixels": [
                    [-8, 0, '#00FF00'], [-7, 0, '#00FF00'], [-6, 0, '#00FF00'], [-5, 0, '#00FF00'],
                    [-4, 0, '#00FF00'], [-3, 0, '#00FF00'], [-2, 0, '#00FF00'],
                    [2, 0, '#00FF00'], [3, 0, '#00FF00'], [4, 0, '#00FF00'], [5, 0, '#00FF00'],
                    [6, 0, '#00FF00'], [7, 0, '#00FF00'], [8, 0, '#00FF00'],
                    [0, -8, '#00FF00'], [0, -7, '#00FF00'], [0, -6, '#00FF00'], [0, -5, '#00FF00'],
                    [0, -4, '#00FF00'], [0, -3, '#00FF00'], [0, -2, '#00FF00'],
                    [0, 2, '#00FF00'], [0, 3, '#00FF00'], [0, 4, '#00FF00'], [0, 5, '#00FF00'],
                    [0, 6, '#00FF00'], [0, 7, '#00FF00'], [0, 8, '#00FF00'],
                    [0, 0, '#FF0000']
                ]
            },
            {
                "name": "Шаблон 2 (точка)",
                "pixels": [
                    [-3, 0, '#FFFFFF'], [-2, 0, '#FFFFFF'],
                    [2, 0, '#FFFFFF'], [3, 0, '#FFFFFF'],
                    [0, -3, '#FFFFFF'], [0, -2, '#FFFFFF'],
                    [0, 2, '#FFFFFF'], [0, 3, '#FFFFFF'],
                    [-4, 0, '#000000'], [-1, 0, '#000000'], [1, 0, '#000000'], [4, 0, '#000000'],
                    [0, -4, '#000000'], [0, -1, '#000000'], [0, 1, '#000000'], [0, 4, '#000000'],
                    [0, 0, '#00FFFF']
                ]
            },
            {
                "name": "Шаблон 3 (диагональ)",
                "pixels": [
                    [0, 0, '#FF0000'],
                    [-2, -2, '#00FF00'], [-1, -1, '#00FF00'],
                    [1, 1, '#00FF00'], [2, 2, '#00FF00'],
                    [-2, 2, '#00FF00'], [-1, 1, '#00FF00'],
                    [1, -1, '#00FF00'], [2, -2, '#00FF00'],
                ]
            }
        ]
        for template in default_templates_data:
            self.save_custom_template(template['name'], template['pixels'])

    def get_custom_templates(self) -> list:
        """Get the list of loaded custom templates."""
        with self.lock:
            return self._custom_templates.copy()

    def get_custom_template_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """Get a specific custom template by its name."""
        with self.lock:
            for template in self._custom_templates:
                if template['name'] == name:
                    return template.copy()
        return None

    def save_custom_template(self, name: str, pixels: List[List[Any]]) -> bool:
        """Save a custom pixel template to the profiles directory."""
        filename = f"{name}.json"
        filepath = os.path.join(self.profiles_dir, filename)
        template_data = {"name": name, "pixels": pixels}
        try:
            with self.lock:
                with open(filepath, 'w', encoding='utf-8') as f:
                    json.dump(template_data, f, indent=2, ensure_ascii=False)
            # Update in-memory list
            found = False
            for i, t in enumerate(self._custom_templates):
                if t['name'] == name:
                    self._custom_templates[i] = template_data
                    found = True
                    break
            if not found:
                self._custom_templates.append(template_data)
            logging.info(f"Custom template '{name}' saved to {filepath}")
            return True
        except Exception as e:
            logging.error(f"Failed to save custom template '{name}' to {filepath}: {e}")
            return False

    def delete_custom_template(self, name: str) -> bool:
        """Delete a custom pixel template from the profiles directory."""
        filename = f"{name}.json"
        filepath = os.path.join(self.profiles_dir, filename)
        try:
            with self.lock:
                if os.path.exists(filepath):
                    os.remove(filepath)
            # Remove from in-memory list
            self._custom_templates = [t for t in self._custom_templates if t['name'] != name]
            logging.info(f"Custom template '{name}' deleted from {filepath}")
            return True
        except Exception as e:
            logging.error(f"Failed to delete custom template '{name}' from {filepath}: {e}")
            return False

    def rename_custom_template(self, old_name: str, new_name: str) -> bool:
        """Rename a custom pixel template in the profiles directory."""
        old_filename = f"{old_name}.json"
        new_filename = f"{new_name}.json"
        old_filepath = os.path.join(self.profiles_dir, old_filename)
        new_filepath = os.path.join(self.profiles_dir, new_filename)
        try:
            with self.lock:
                if os.path.exists(old_filepath):
                    os.rename(old_filepath, new_filepath)
            # Update in-memory list
            for t in self._custom_templates:
                if t['name'] == old_name:
                    t['name'] = new_name
                    break
            logging.info(f"Custom template '{old_name}' renamed to '{new_name}'")
            return True
        except Exception as e:
            logging.error(f"Failed to rename custom template from {old_filepath} to {new_filepath}: {e}")
            return False
    def load_settings(self) -> bool:
        """Thread-safe загрузка настроек."""
        try:
            logging.debug(f"Attempting to load settings from: {os.path.abspath(self.settings_file)}")
            if os.path.exists(self.settings_file):
                with open(self.settings_file, 'r', encoding='utf-8') as f:
                    saved_settings = json.load(f)
                with self.lock:
                    self.settings.update(saved_settings)
                logging.info(f"Settings loaded from {self.settings_file}")
                return True
        except Exception as e:
            logging.error(f"Failed to load settings: {e}")
            return False
    def save_settings(self) -> bool:
        """Thread-safe сохранение настроек."""
        try:
            with self.lock:
                settings_copy = self.settings.copy()
            with open(self.settings_file, 'w', encoding='utf-8') as f:
                json.dump(settings_copy, f, indent=2, ensure_ascii=False)
            logging.info(f"Settings saved to {os.path.abspath(self.settings_file)}")
            return True
        except Exception as e:
            logging.error(f"Failed to save settings: {e}")
            return False
    def load_from_file(self, filepath: str) -> bool:
        """Thread-safe загрузка из указанного файла."""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                loaded_settings = json.load(f)
            with self.lock:
                self.settings.update(loaded_settings)
            logging.info(f"Settings loaded from {filepath}")
            return True
        except Exception as e:
            logging.error(f"Failed to load settings from {filepath}: {e}")
            return False
    def reset_to_defaults(self) -> None:
        """Thread-safe сброс к настройкам по умолчанию."""
        with self.lock:
            self.settings = self.DEFAULT_SETTINGS.copy()
        logging.info("Settings reset to defaults")
    def validate_resolution(self, width: int, height: int) -> bool:
        """Проверка корректности разрешения."""
        return (800 <= width <= 7680 and
                600 <= height <= 4320 and
                width > 0 and height > 0)
    def set_resolution(self, width: int, height: int) -> bool:
        """Установка разрешения с проверкой."""
        if not self.validate_resolution(width, height):
            logging.warning(f"Некорректное разрешение: {width}x{height}")
            return False
        with self.lock:
            old_width = self.settings.get('screen_width', 1920)
            old_height = self.settings.get('screen_height', 1080)
            self.settings['screen_width'] = width
            self.settings['screen_height'] = height
        logging.info(f"Разрешение изменено с {old_width}x{old_height} на {width}x{height}")
        return True
    def get_center_position(self) -> Tuple[int, int]:
        """Получить центральную позицию экрана."""
        width = self.get('screen_width', 1920)
        height = self.get('screen_height', 1080)
        return width // 2, height // 2
    def get_overlay_position(self) -> Tuple[int, int, int, int]:
        """Получить позицию и размер области оверлея."""
        screen_width = self.get('screen_width', 1920)
        screen_height = self.get('screen_height', 1080)
        overlay_size = self.get('overlay_size', 100)
        center_x = screen_width // 2 - overlay_size // 2
        center_y = screen_height // 2 - overlay_size // 2
        center_x = max(0, min(screen_width - overlay_size, center_x))
        center_y = max(0, min(screen_height - overlay_size, center_y))
        return center_x, center_y, overlay_size, overlay_size
    def get(self, key: str, default: Any = None) -> Any:
        """Thread-safe получение значения настройки."""
        with self.lock:
            return self.settings.get(key, default)
    def set(self, key: str, value: Any) -> None:
        """Thread-safe установка значения настройки."""
        with self.lock:
            self.settings[key] = value
    def update(self, new_settings: Dict[str, Any]) -> None:
        """Thread-safe обновление множественных настроек."""
        with self.lock:
            self.settings.update(new_settings)
    def get_all(self) -> Dict[str, Any]:
        """Thread-safe получение всех настроек."""
        with self.lock:
            return self.settings.copy()
    def export_settings(self, filepath: str) -> bool:
        """Экспорт настроек в указанный файл."""
        try:
            with self.lock:
                settings_copy = self.settings.copy()
            export_data = {
                'metadata': {
                    'version': '2.1',
                    'export_time': __import__('datetime').datetime.now().isoformat(),
                    'resolution': f"{settings_copy['screen_width']}x{settings_copy['screen_height']}"
                },
                'settings': settings_copy
            }
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)
            logging.info(f"Settings exported to {filepath}")
            return True
        except Exception as e:
            logging.error(f"Failed to export settings to {filepath}: {e}")
            return False
    def import_settings(self, filepath: str) -> bool:
        """Импорт настроек из файла."""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                import_data = json.load(f)
            if isinstance(import_data, dict) and 'settings' in import_data:
                settings_to_import = import_data['settings']
                metadata = import_data.get('metadata', {})
                logging.info(f"Importing settings with metadata: {metadata}")
            else:
                settings_to_import = import_data
            with self.lock:
                self.settings.update(settings_to_import)
            logging.info(f"Settings imported from {filepath}")
            return True
        except Exception as e:
            logging.error(f"Failed to import settings from {filepath}: {e}")
            return False