#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
CrossHud_By_PetyaBlatnoy v2.1

Главная точка входа в приложение.
"""

import sys
import os
import argparse
import logging
from crosshud_app import CrossHudApp


def setup_paths():
    """Настройка путей для приложения."""
    # Добавить текущую директорию в путь поиска модулей
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if current_dir not in sys.path:
        sys.path.insert(0, current_dir)


def parse_arguments():
    """Парсинг аргументов командной строки."""
    parser = argparse.ArgumentParser(
        description='CrossHud_By_PetyaBlatnoy',
        epilog='Автор: PetyaBlatnoy'
    )

    parser.add_argument('--profile',
                        help='Загрузить конкретный профиль настроек')
    parser.add_argument('--minimize', action='store_true',
                        help='Запустить свернутым в трей')
    parser.add_argument('--enable', action='store_true',
                        help='Автоматически включить прицел при запуске')
    parser.add_argument('--debug', action='store_true',
                        help='Включить отладочный режим')
    parser.add_argument('--no-tray', action='store_true',
                        help='Отключить системный трей (полное закрытие по крестику)')
    parser.add_argument('--version', action='version',
                        version='CrossHud_By_PetyaBlatnoy v2.1')

    return parser.parse_args()


def setup_logging(debug_mode=False):
    """Настройка системы логирования."""
    level = logging.DEBUG if debug_mode else logging.INFO

    # Создание папки для логов
    log_dir = os.path.join(os.path.expanduser("~"), "CrossHud_By_PetyaBlatnoy", "logs")
    os.makedirs(log_dir, exist_ok=True)

    # Настройка форматирования
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    # Файловый обработчик
    log_file = os.path.join(log_dir, "crosshud.log")
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setFormatter(formatter)
    file_handler.setLevel(level)

    # Консольный обработчик
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    console_handler.setLevel(level)

    # Настройка корневого логгера
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)


def load_profile(app, profile_name):
    """Загрузка профиля настроек."""
    if not profile_name:
        return

    try:
        # Попытаться найти файл профиля
        profile_paths = [
            f"{profile_name}_profile.json",
            f"{profile_name}.json",
            os.path.join("profiles", f"{profile_name}.json"),
            os.path.join(os.path.expanduser("~"), "CrossHud_By_PetyaBlatnoy", "profiles", f"{profile_name}.json")
        ]

        for path in profile_paths:
            if os.path.exists(path):
                if app.settings_manager.load_from_file(path):
                    logging.info(f"Загружен профиль: {profile_name} из {path}")
                    return
                else:
                    logging.warning(f"Не удалось загрузить профиль из {path}")

        logging.warning(f"Профиль {profile_name} не найден")

    except Exception as e:
        logging.error(f"Ошибка загрузки профиля {profile_name}: {e}")


def check_dependencies():
    """Проверка наличия необходимых зависимостей."""
    required_modules = ['tkinter']
    optional_modules = ['win32gui', 'win32con', 'win32api', 'win32com.client', 'pystray', 'PIL']

    missing_required = []
    missing_optional = []

    for module in required_modules:
        try:
            __import__(module)
        except ImportError:
            missing_required.append(module)

    for module in optional_modules:
        try:
            __import__(module)
        except ImportError:
            missing_optional.append(module)

    if missing_required:
        print(f"ОШИБКА: Отсутствуют необходимые модули: {', '.join(missing_required)}")
        print("Установите их командой: pip install -r requirements.txt")
        return False

    if missing_optional:
        missing_names = []
        for module in missing_optional:
            if module in ['win32gui', 'win32con', 'win32api', 'win32com.client']:
                missing_names.append('pywin32')
            elif module in ['pystray']:
                missing_names.append('pystray')
            elif module in ['PIL']:
                missing_names.append('Pillow')

        unique_missing = list(set(missing_names))
        print(f"ПРЕДУПРЕЖДЕНИЕ: Отсутствуют дополнительные модули: {', '.join(unique_missing)}")
        print("Некоторые функции могут быть недоступны:")
        if 'pywin32' in unique_missing:
            print(" - Без pywin32: ограничена прозрачность окна и скрытие по ПКМ")
        if 'pystray' in unique_missing or 'Pillow' in unique_missing:
            print(" - Без pystray/Pillow: отключена функция системного трея")
        print(f"Установите их командой: pip install {' '.join(unique_missing)}")

    return True


def create_default_profiles():
    """Создание профилей по умолчанию если они не существуют."""
    profiles_dir = os.path.join(os.path.expanduser("~"), "CrossHud_By_PetyaBlatnoy", "profiles")
    os.makedirs(profiles_dir, exist_ok=True)

    # Создание профилей
    profiles = {
        "profile1": {
            "enabled": True,
            "size": 20,
            "thickness": 2,
            "gap": 4,
            "color": "#00FF00",
            "center_dot": True,
            "center_dot_color": "#FF0000",
            "outline_enabled": True,
            "outline_color": "#000000",
            "outline_width": 1
        },
        "profile2": {
            "enabled": True,
            "size": 15,
            "thickness": 2,
            "gap": 2,
            "color": "#FFFFFF",
            "center_dot": True,
            "center_dot_color": "#00FFFF",
            "outline_enabled": True,
            "outline_color": "#000000",
            "outline_width": 1
        },
        "profile3": {
            "enabled": True,
            "size": 25,
            "thickness": 3,
            "gap": 5,
            "color": "#FF6600",
            "center_dot": False,
            "opacity": 0.8
        }
    }

    for profile_name, settings in profiles.items():
        profile_path = os.path.join(profiles_dir, f"{profile_name}.json")
        if not os.path.exists(profile_path):
            try:
                import json
                with open(profile_path, 'w', encoding='utf-8') as f:
                    json.dump(settings, f, indent=2, ensure_ascii=False)
                logging.info(f"Создан профиль {profile_name}")
            except Exception as e:
                logging.warning(f"Не удалось создать профиль {profile_name}: {e}")


def setup_process_management():
    """Настройка управления процессом для корректного завершения."""
    try:
        import psutil
        import atexit

        # Получить текущий процесс
        current_process = psutil.Process()

        def cleanup_process():
            """Принудительное завершение всех дочерних процессов."""
            try:
                # Завершить все дочерние процессы
                children = current_process.children(recursive=True)
                for child in children:
                    try:
                        child.terminate()
                    except psutil.NoSuchProcess:
                        pass

                # Дождаться завершения дочерних процессов
                psutil.wait_procs(children, timeout=3)

                # Принудительно убить не завершившиеся процессы
                for child in children:
                    try:
                        if child.is_running():
                            child.kill()
                    except psutil.NoSuchProcess:
                        pass

            except Exception as e:
                logging.warning(f"Ошибка при завершении дочерних процессов: {e}")

        # Зарегистрировать функцию очистки
        atexit.register(cleanup_process)

    except ImportError:
        logging.warning("psutil не доступен, управление процессами ограничено")


def main():
    """Главная функция приложения"""
    app = None
    try:
        # Настройка путей
        setup_paths()

        # Парсинг аргументов
        args = parse_arguments()

        # Настройка логирования
        setup_logging(args.debug)

        logging.info("=" * 50)
        logging.info("Запуск CrossHud_By_PetyaBlatnoy v2.1")
        logging.info("Автор: PetyaBlatnoy")
        logging.info("=" * 50)

        # Настройка управления процессами
        setup_process_management()

        # Проверка зависимостей
        if not check_dependencies():
            input("Нажмите Enter для выхода...")
            sys.exit(1)

        # Создание профилей по умолчанию
        create_default_profiles()

        # Отключение трея если указано
        if args.no_tray:
            # Временно отключить pystray для этого запуска
            import sys
            sys.modules['pystray'] = None
            logging.info("Системный трей отключен по запросу пользователя")

        # Создание и запуск приложения
        logging.info("Создание главного приложения...")
        app = CrossHudApp()

        # Принудительное закрытие если трей отключен
        if args.no_tray:
            app.force_exit = True

        # Загрузка профиля если указан
        if args.profile:
            load_profile(app, args.profile)

        # Автоматическое включение прицела
        if args.enable:
            app.settings_manager.set('enabled', True)
            logging.info("Прицел включен автоматически")

        # Сворачивание в трей если указано
        if args.minimize:
            if not args.no_tray:
                app.hide_main_window()
                logging.info("Приложение запущено в свернутом виде")
            else:
                logging.info("Минимизация недоступна при отключенном трее")

        logging.info("Приложение готово к работе")

        # Запуск главного цикла
        app.run()

    except ImportError as e:
        error_msg = f"Отсутствуют необходимые модули: {e}"
        print(error_msg)
        logging.error(error_msg)
        print("\nДля установки зависимостей выполните:")
        print("pip install -r requirements.txt")
        input("Нажмите Enter для выхода...")
        sys.exit(1)

    except KeyboardInterrupt:
        logging.info("Приложение остановлено пользователем")
        if app:
            app.force_exit = True
            app.cleanup()

    except Exception as e:
        error_msg = f"Критическая ошибка при запуске приложения: {e}"
        print(error_msg)
        logging.error(error_msg, exc_info=True)
        if app:
            app.force_exit = True
            app.cleanup()
        input("Нажмите Enter для выхода...")
        sys.exit(1)

    finally:
        # Принудительное завершение всех остаточных процессов
        try:
            import psutil
            current_process = psutil.Process()
            for child in current_process.children(recursive=True):
                try:
                    child.terminate()
                except:
                    pass
        except ImportError:
            pass


if __name__ == "__main__":
    main()